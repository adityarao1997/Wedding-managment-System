<?php 

    $this->load->view('Layout/include/header');
    $this->load->view('Layout/include/sidebar');
    $this->load->view('Admin/Decoration_F/DecoEdit_Main.php');
    $this->load->view('Layout/include/footer');


?>







