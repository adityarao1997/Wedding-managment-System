<?php 

    $this->load->view('Layout/include/header');
    $this->load->view('Layout/include/sidebar');
    $this->load->view('Admin/Dashboard/indexM.php');
    $this->load->view('Layout/include/footer');


?>






