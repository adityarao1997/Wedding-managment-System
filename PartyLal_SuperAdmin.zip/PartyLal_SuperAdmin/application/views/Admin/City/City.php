<?php 

    $this->load->view('Layout/include/header');
    $this->load->view('Layout/include/sidebar');
    $this->load->view('Admin/City/City_work.php');
    $this->load->view('Layout/include/footer');


?>
