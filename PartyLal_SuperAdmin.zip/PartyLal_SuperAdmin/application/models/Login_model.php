<?php

 /**
  * 
  */
 class Login_model extends CI_Model
 {
 	
 	 public function login_all($email, $password, $role)
 	 {
 	      $query = $this->db->where(['email'=>$email, 'password'=>$password, 'role'=>$role])->get('admin');
 	       if ($query->num_rows() > 0) {
 	       	   
 	       	   return $query->row()->id;
 	       }
 	 }

 	/*
     * function to add new vendor
     */
    function add_vendor($params)
    {
        $this->db->insert('admin',$params);
        return $this->db->insert_id();
    }
      
 }
?>