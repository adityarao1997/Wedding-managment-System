<?php echo form_open('AdminDash/AdminEdit1/'.$result['id'],array("class"=>"form-horizontal")); ?>
<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <div class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1 class="m-0 text-dark"><strong>Admin</strong> List</h1>
          </div><!-- /.col -->
          <div class="col-sm-12 mt-3" style="background:#EAE7E7; height: 6vh;">
            <ol class="breadcrumb">
              <li class="breadcrumb-item"><a href="<?php echo base_url('AdminDash');?>">Home</a><i
              class="fas fa-angle-double-right mx-2 white-text" aria-hidden="true"></i></li>
              <li class="active"><strong>Edit Admin</strong></li>
            </ol>
          </div><!-- /.col -->
        </div><!-- /.row -->
      </div><!-- /.container-fluid -->
     
 <section class="col-lg-12 connectedSortable">
 <center>
    <div class="col-lg-8">
       <div class="card-body login-card-body" style="border: 1px solid green;">
        <h5 class="text-dark">Edit<b> Admin Detail</b></h5><br><br>
             
           <div class="row"> 
                <div class="col-sm-6">
                  <label for="type_name" class="col-sm-6 "><span class="text-danger">*</span>Name</label>
                    <div class="col-md-10">
                        <input type="text" name="name" value="<?php echo ($this->input->post('name') ? $this->input->post('name') : $result['name']); ?>" class="form-control" id="name" />
                        <span class="text-danger"><?php echo form_error('name');?></span>
		            </div>
                </div>
                <div class="col-sm-6">
                  <label for="type_name" class="col-sm-6 "><span class="text-danger">*</span>Contact</label>
                  <div class="col-md-10">
                        <input type="text" name="contact" value="<?php echo ($this->input->post('contact') ? $this->input->post('contact') : $result['contact']); ?>" class="form-control" id="contact" />
                        <span class="text-danger"><?php echo form_error('contact');?></span>
		            </div>
               </div>
            </div><br> 
            <div class="row"> 
                <div class="col-sm-6">
                  <label for="type_name" class="col-sm-6 "><span class="text-danger">*</span>Email</label>
                     <div class="col-md-10">
                        <input type="text" name="email" value="<?php echo ($this->input->post('email') ? $this->input->post('email') : $result['email']); ?>" class="form-control" id="email" />
                        <span class="text-danger"><?php echo form_error('email');?></span>
		            </div>
                </div>
                <div class="col-sm-6">
                  <label for="type_name" class="col-sm-6 "><span class="text-danger">*</span>Password</label>
                      <div class="col-md-10">
                        <input type="text" name="password" value="<?php echo ($this->input->post('password') ? $this->input->post('password') : $result['password']); ?>" class="form-control" id="password" />
                        <span class="text-danger"><?php echo form_error('password');?></span>
		            </div>
               </div>
            </div><br> 
             <div class="row"> 
                <div class="col-sm-6">
                  <label for="type_name" class="col-sm-6 "><span class="text-danger">*</span>City</label>
                     <div class="col-md-10">
                        <input type="text" name="city" value="<?php echo ($this->input->post('city') ? $this->input->post('city') : $result['city']); ?>" class="form-control" id="city" />
                        <span class="text-danger"><?php echo form_error('city');?></span>
		            </div>
                </div>
                <div class="col-sm-6">
                  <label for="type_name" class="col-sm-6 "><span class="text-danger">*</span>Status</label>
                      <div class="col-md-10">
                        <select name="status" class="form-control"> 
                            <option>Select</option>
                            <option value="1">Accept</option>
                            <option value="2">Decline</option>
                          </select>
                        <span class="text-danger"><?php echo form_error('status');?></span>
		            </div>
               </div>
            </div><br>
                      
    <div class="form-group">
      <div class="col-sm-offset-4 col-sm-8">
        <?php echo form_submit(['value' => 'submit','class'=>'btn btn-primary float-sm-right']);?>
      </div>
    </div>
       </div>
     </div>
</center>
</section>