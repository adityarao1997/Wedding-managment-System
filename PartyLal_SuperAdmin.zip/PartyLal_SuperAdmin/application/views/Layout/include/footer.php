
<footer class="main-footer" style="margin-left: -20px;">
    <center><div class="float-right d-none d-sm-block">
      <b>Version</b> 3.0.1
    </div>
    <strong>Copyright © 2014-2019 <a href="http://Techhelper.in">Techhelper.in</a>.</strong> All rights
    reserved.</center>
  </footer>

   <!-- Control Sidebar -->
  <aside class="control-sidebar control-sidebar-dark">
    <!-- Control sidebar content goes here -->
  </aside>

<!-- ./wrapper -->

<!-- jQuery -->
<script src="<?php echo base_url();?>resource/plugins/jquery/jquery.min.js"></script>
<!-- Bootstrap 4 -->
<script src="<?php echo base_url();?>resource/plugins/bootstrap/js/bootstrap.bundle.min.js"></script>
<!-- AdminLTE App -->
<script src="<?php echo base_url();?>resource/dist/js/adminlte.min.js"></script>
<!-- AdminLTE for demo purposes -->
<script src="<?php echo base_url();?>resource/dist/js/demo.js"></script>
</body>
</html>