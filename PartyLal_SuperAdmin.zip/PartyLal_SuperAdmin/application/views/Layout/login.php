<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?>
<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <title>PartyLal | Login</title>
  <!-- Tell the browser to be responsive to screen width -->
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="shortcut icon" href="resource/dist/img/favicon.ico">
  <!-- Font Awesome -->
  <link rel="stylesheet" href="<?php echo base_url();?>resource/plugins/fontawesome-free/css/all.min.css">
  <!-- Ionicons -->
  <link rel="stylesheet" href="https://code.ionicframework.com/ionicons/2.0.1/css/ionicons.min.css">
  <!-- icheck bootstrap -->
  <link rel="stylesheet" href="<?php echo base_url();?>resource/plugins/icheck-bootstrap/icheck-bootstrap.min.css">
  <!-- Theme style -->
  <link rel="stylesheet" href="<?php echo base_url();?>resource/dist/css/adminlte.min.css">
  <!-- Google Font: Source Sans Pro -->
  <link href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,400i,700" rel="stylesheet">
</head>
<body class="hold-transition login-page" style="background: #161B21;">
<div class="login-box">
     <?php echo form_open("Login/all_login"); ?>
  <div class="login-logo" >
     <a href=""style="color: white;"><b>PARTYLAL</b> Super Admin </a>
  </div>
     <?php if($error = $this->session->flashdata('login_response')):?>
        <div class="row">
          <div class="col-lg-12">
            <div class="alert alert-dismissible alert-danger">
               <?php echo $error; ?>
            </div>
          </div>
         </div>
     <?php endif; ?>  
  <!-- /.login-logo -->
  <div class="card">
    <div class="card-body login-card-body">
      <p class="login-box-msg">Sign in to start your session</p>
        <div class="form-group">
                  <select class="form-control" name="role">
                   <option>Select your Role</option>
                   <option value="1">Super Admin</option>
                   <option value="2">Admin</option>
                  </select>
            </div>
        <div class="input-group mb-3">
          <?php echo form_input(['name' => 'email','class'=>'form-control', 'placeholder'=>'Email','value'=>set_value('email')])?>
          <div class="input-group-append">
            <div class="input-group-text">
              <span class="fas fa-envelope"></span>
            </div>
          </div>
        </div>
         <div class="col-lg-12">
           <?php echo form_error('email','<div class="text-danger">','</div>');?>
        </div>

        <div class="input-group mb-3">
          <?php echo form_password(['name' => 'password','class'=>'form-control', 'placeholder'=>'Password','value'=>set_value('password')])?>
          <div class="input-group-append">
            <div class="input-group-text">
              <span class="fas fa-lock"></span>
            </div>
          </div>
        </div>
        <div class="col-lg-12">
        <?php echo form_error('password','<div class="text-danger">','</div>');?>
        </div>

        <div class="row">
          <div class="col-8">
            <div class="icheck-primary">
                 
            </div>
          </div>
         
          <div class="col-12">
            <?php echo form_submit(['value' =>'Submit','class'=>'btn btn-primary btn-block'])?>
          </div>
        </div>

      <div class="social-auth-links text-center mb-3" >
        <p>- OR -</p>
        <a class="">
           <?php echo anchor('Login/register','<i class="btn btn-block btn-primary fas fa-envelope"> Admin Register  </i>')?>
        </a>
       
      </div>
      <!-- /.social-auth-links -->

      <p class="mb-1">
        <a href="forgot-password.html">I forgot my password</a>
      </p>
      
    </div>
    <!-- /.login-card-body -->
  </div>
  <?php echo form_close();?>
</div>
<!-- /.login-box -->

<!-- jQuery -->
<script src="<?php echo base_url();?>resource/plugins/jquery/jquery.min.js"></script>
<!-- Bootstrap 4 -->
<script src="<?php echo base_url();?>resource/plugins/bootstrap/js/bootstrap.bundle.min.js"></script>
<!-- AdminLTE App -->
<script src="<?php echo base_url();?>resource/dist/js/adminlte.min.js"></script>

</body>
</html>
