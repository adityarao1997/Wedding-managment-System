<?php defined('BASEPATH') OR exit('No direct script access allowed');?> 
 <div class="content-wrapper">

     <div class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1 class="m-0 text-dark"> Type</h1>
          </div><!-- /.col -->
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="#">Home</a></li>
              <li class="breadcrumb-item active">Dashboard</li>
            </ol>
          </div><!-- /.col -->
        </div><!-- /.row -->
      </div><!-- /.container-fluid -->
    </div>
    <!-- /.content-header -->

    <!-- Main content -->
    <section class="col-lg-12 connectedSortable">
        <div class="Container col-md-12">
         <?php echo form_open("AdminDash/TypesAdd" ,['class'=>'navbar-form navbar-right ','role'=>'search']);?>
         <div class="form-group col-md-4 ">
            <?php echo form_input(['name' => 'query','class'=>'form-control', 'placeholder'=>'Enter Email','value'=>set_value('username')]);?>
         </div>
         <div class="form-group col-md-4">
            <?php echo form_submit(['value' => 'search','class'=>'btn btn-primary']);?>
             <?php echo form_submit(['value' => 'Add New','class'=>'btn btn-primary float-sm-right']);?>
        </div>
           
       
     </div>
     
     
    
   
     <table class="table table-hover table-active" >
  <thead style="background-color:#007bff; color: white; ">
    <tr>
      <th scope="col">ID</th>
      <th scope="col">Vendor Typeid</th>
      <th scope="col">Type Name</th>
      <th scope="col">Edit</th>
      <th scope="col">Delete</th>
    </tr>
  </thead>
  <tbody>
  <?php foreach($types as $t){ ?>
    <tr>
    <td><?php echo $t['id']; ?></td>
    <td><?php echo $t['vendor_typeid']; ?></td>
    <td><?php echo $t['type_name']; ?></td>
  
    
            <td>
             <button class="btn btn-block btn-outline-info">
               <a href="<?php echo site_url('AdminDash/Type_edit/'.$t['id']); ?>">Edit</a> 
               </button>
            </td>
            <td>
             <button class="btn btn-block btn-outline-danger">
              <a href="<?php echo site_url('AdminDash/Type_remove/'.$t['id']); ?>">Delete</a> 
               </button>
            </td>
        
    </tr>
  <?php } ?>
  </tbody>
</table>
    </section>
 </div>    
