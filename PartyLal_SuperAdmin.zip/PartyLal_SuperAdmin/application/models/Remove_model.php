<?php

    /**
     * 
     */
    class Remove_model extends CI_Model
    {
    	
    	 function __construct()
         {
            parent::__construct();
         }
    
 
    function get_vendor_type($id)
    {
        return $this->db->get_where('vendor_type',array('id'=>$id))->row_array();
    }
    /*
     * function to delete vendor_type
     */
    function delete_vendor_type($id)
    {
        return $this->db->delete('vendor_type',array('id'=>$id));
    }


    /*
     * Get food by id
     */
    function get_food($id)
    {
        return $this->db->get_where('food',array('id'=>$id))->row_array();
    }
    /*
     * function to delete food
     */
    function delete_food($id)
    {
        return $this->db->delete('food',array('id'=>$id));
    }

    

    /*
     * Get type by id
     */
    function get_type($id)
    {
        return $this->db->get_where('types',array('id'=>$id))->row_array();
    }
    /*
     * function to delete type
     */
    function delete_type($id)
    {
        return $this->db->delete('types',array('id'=>$id));
    }
  

    /*
     * Get vendor by id
     */
    function get_vendor($id)
    {
        return $this->db->get_where('vendors',array('id'=>$id))->row_array();
    }
    /*
     * function to delete vendor
     */
    function delete_vendor($id)
    {
        return $this->db->delete('vendors',array('id'=>$id));
    }


    /*
     * Get facility by id
     */
    function get_facility($id)
    {
        return $this->db->get_where('facilities',array('id'=>$id))->row_array();
    }
    /*
     * function to delete facility
     */
    function delete_facility($id)
    {
        return $this->db->delete('facilities',array('id'=>$id));
    }


    /*
     * Get setup by id
     */
    function get_setup($id)
    {
        return $this->db->get_where('setup',array('id'=>$id))->row_array();
    }
    /*
     * function to delete setup
     */
    function delete_setup($id)
    {
        return $this->db->delete('setup',array('id'=>$id));
    }


    /*
     * Get decoration_type by id
     */
    function get_decoration_type($id)
    {
        return $this->db->get_where('decoration_type',array('id'=>$id))->row_array();
    }
    /*
     * function to delete decoration_type
     */
    function delete_decoration_type($id)
    {
        return $this->db->delete('decoration_type',array('id'=>$id));
    }


    /*
     * Get special by id
     */
    function get_special($id)
    {
        return $this->db->get_where('special',array('id'=>$id))->row_array();
    }
    /*
     * function to delete special
     */
    function delete_special($id)
    {
        return $this->db->delete('special',array('id'=>$id));
    }
        
        
    /*
     * Get special by id
     */
    function get_city($id)
    {
        return $this->db->get_where('city',array('id'=>$id))->row_array();
    }
    /*
     * function to delete special
     */
    function delete_city($id)
    {
        return $this->db->delete('city',array('id'=>$id));
    }
        
     /*
     * Get admin by id
     */
    function get_admin($id)
    {
        return $this->db->get_where('admin',array('id'=>$id))->row_array();
    }
     /*
     * function to delete admin
     */
    function delete_admin($id)
    {
        return $this->db->delete('admin',array('id'=>$id));
    }
        
    /*
     * Get vENDER by id
     */
    function get_vender($id)
    {
        return $this->db->get_where('vendors',array('id'=>$id))->row_array();
    }
     /*
     * function to delete Vender
     */
    function delete_vender($id)
    {
        return $this->db->delete('vendors',array('id'=>$id));
    }
}?>