<?php



  class Login extends CI_Controller
 {

   function __construct()
    {
        parent::__construct();
        $this->load->model('Login_model');
    } 
 	
 	public function index()
 	{    
        $this->session->unset_userdata('id');
 		   $this->load->view('layout/login');
 	}

 	public function all_login()
 	{
 		    $this->form_validation->set_rules('email', 'email', 'required');
        $this->form_validation->set_rules('password', 'password', 'required');
        $this->form_validation->set_rules('role', 'role', 'required');
        $this->form_validation->set_error_delimiters('<div class="error">','</div>');
             if ($this->form_validation->run()) {
             		    
             		      $email = $this->input->post('email');
                      $password = $this->input->post('password');
                      $role = $this->input->post('role');
                      $this->load->model('Login_model');
                      $id = $this->Login_model->login_all($email, $password, $role);
                      if($id > 0){
                            $this->session->set_userdata(['id'=>$id]);
                            if($role == '1'){
                                   return redirect('AdminDash');
                                    }elseif($role == '2')
                                          {
                                           return redirect('Dashboard');
                                          }
                          }else{
                               $error = $this->session->set_flashdata('login_response', 'Invalid username/password');
                                return redirect($this->$config['base_url']);
                               }
           	}else{
           		$this->load->view('layout/login');
           	}
         }

         public function register()
         {
                   $this->load->model('Login_model');
              
                 $data['_view'] = 'layout/register';
                 $this->load->view('layout/register',$data);

           
         }

          public function Admin_Regis()
          {
              
             $this->load->library('form_validation');
             $this->form_validation->set_rules('name','Name','required');
             $this->form_validation->set_rules('contact','Contact No','numeric|required');
             $this->form_validation->set_rules('email','Email Id','required|trim|valid_email');
             $this->form_validation->set_rules('address','address','required');
             $this->form_validation->set_rules('city','city','required');
             $this->form_validation->set_rules('pin','pin','numeric|required');
             $this->form_validation->set_rules('password','Password','required|alpha_numeric');
             $this->form_validation->set_rules('cpassword','cpassword','required|alpha_numeric|matches[password]');
             $this->form_validation->set_rules('terms','terms','required');
             $this->form_validation->set_rules('role','role','required');
    
                    if($this->form_validation->run())     
                        {   
                            $params = array(
                        'name' => $this->input->post('name'),
                        'contact' => $this->input->post('contact'),
                        'email' => $this->input->post('email'),
                        'address' => $this->input->post('address'),
                        'city' => $this->input->post('city'),
                        'pin' => $this->input->post('pin'),
                        'password' => $this->input->post('password'),
                        'cpassword' => $this->input->post('cpassword'),
                        'terms' => $this->input->post('terms'),
                        'role' => $this->input->post('role'),
                            );
                            
                            $vendor_id = $this->Login_model->add_vendor($params);
                            redirect('Login/index');

                        }
                        else
                        {
                            
                            
                            $data['_view'] = 'Layout/register';
                            $this->load->view('Layout/register',$data);
                        }
                    }  

   

 	}
?>