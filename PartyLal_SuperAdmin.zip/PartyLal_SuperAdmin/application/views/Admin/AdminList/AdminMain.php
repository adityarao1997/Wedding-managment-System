<?php defined('BASEPATH') OR exit('No direct script access allowed');?> 
<body class="">


 
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <div class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1 class="m-0 text-dark"><strong>Admin</strong> List</h1>
          </div><!-- /.col -->
          <div class="col-sm-12 mt-3" style="background:#EAE7E7; height: 6vh;">
            <ol class="breadcrumb">
              <li class="breadcrumb-item"><a href="<?php echo base_url('AdminDash');?>">Home</a><i
              class="fas fa-angle-double-right mx-2 white-text" aria-hidden="true"></i></li>
              <li class="active"><strong>View All-Admins</strong></li>
            </ol>
          </div><!-- /.col -->
        </div><!-- /.row -->
      </div><!-- /.container-fluid -->
    </div>
    <!-- /.content-header -->

    <!-- Main content -->
    <section class="col-lg-12 connectedSortable">
      <div class="Container col-md-12">
         <?php echo form_open("AdminDash/AddAdmin");?>
          
           <div class="form-group col-md-8 row no-gutters">
              <div class="col">
                <?php echo form_input(['name' => 'query','class'=>'form-control', 'placeholder'=>'Search','value'=>set_value('')]);?>
             </div> 
            <div class="input-group-append mr-2">
                <div class="input-group-text">
                  <span class="fas fa-search"></span>
                </div>
            </div>
             <div class="col-auto ml-5">
                 <?php echo form_submit(['value' => 'search','class'=>'btn btn-success']);?>
                  
             </div>           
             <div class="col-auto ml-5">
                  <?php echo form_submit(['value' => 'Add New','class'=>'btn btn-dark float-sm-right']);?>
             </div>            
                           
                        </div>
        
         
      <center><div class="Container col-md-12">
        <table class="table table-hover table-active" >
              <thead >
                    <tr>
                      <th scope="col">ID</th>
                      <th scope="col">Role</th>
                      <th scope="col">Name</th>
                      <th scope="col">Email</th>
                      <th scope="col">Contact</th>
                      <th scope="col">City</th>
                      <th scope="col">Status</th>
                      <th scope="col">Edit</th>
                      <th scope="col">Delete</th>
                    </tr>
             </thead>
            <tbody class="thead-light">
                <?php foreach($result as $r):?>
                  <tr>
                   <td><?php echo $r->id; ?></td>
                   <td><?php echo $r->role_name; ?></td>
                   <td><?php echo $r->name; ?></td>
                   <td><?php echo $r->email; ?></td>
                   <td><?php echo $r->contact; ?></td>
                   <td><?php echo $r->city; ?></td>
                   <?php if($r->status == '0'):?>
                       <td style="color: red;"><?php echo "pendding"; ?></td>
                   <?php else: ?>
                  <?php if($r->status == '1'): ?>
                  <td style="color: green;"><?php echo "Done"; ?></td>
                  <?php endif;?>
                  <?php endif;?>
                          <td>
                           <button class="btn btn-block btn-outline-info">
                             <a href="<?php echo site_url('AdminDash/AdminEdit1/'.$r->id); ?>">Edit</a> 
                             </button>
                          </td>
                          <td>
                           <button class="btn btn-block btn-outline-danger">
                            <a href="<?php echo site_url('AdminDash/AdminRemove/'.$r->id); ?>">Delete</a> 
                             </button>
                          </td>
                      
                  </tr>
                 <?php endforeach; ?>
            </tbody>
       </table>
    </div></center>
      
         
                                    <!--      Close  -->
        
        </div>
    </section>
            
</div>