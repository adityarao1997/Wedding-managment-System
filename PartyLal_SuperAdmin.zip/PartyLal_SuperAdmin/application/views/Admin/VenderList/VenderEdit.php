<?php 

    $this->load->view('Layout/include/header');
    $this->load->view('Layout/include/sidebar');
    $this->load->view('Admin/VenderList/VenderEditMain.php');
    $this->load->view('Layout/include/footer');


?>
