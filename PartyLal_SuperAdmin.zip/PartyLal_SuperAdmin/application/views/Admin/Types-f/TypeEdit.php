<?php 

    $this->load->view('Layout/include/header');
    $this->load->view('Layout/include/sidebar');
    $this->load->view('Admin/Types-f/TypeEditMain.php');
    $this->load->view('Layout/include/footer');


?>






