<?php 

    $this->load->view('Layout/include/header');
    $this->load->view('Layout/include/sidebar');
    $this->load->view('Admin/Package_F/packageMain.php');
    $this->load->view('Layout/include/footer');


?>
