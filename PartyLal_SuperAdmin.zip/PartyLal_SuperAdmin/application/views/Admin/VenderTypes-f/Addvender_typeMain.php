<?php defined('BASEPATH') OR exit('No direct script access allowed');?> 
<?php echo form_open('AdminDash/Addvender_type',array("class"=>"form-horizontal")); ?>
 <?php if($error = $this->session->flashdata('login_response')):?>
      <div class="row">
        <div class="col-lg-12">
            <div class="alert alert-dismissible alert-danger">
               <?php echo $error; ?>
            </div>
       </div>
      </div>
    <?php endif; ?> 


 <div class="content-wrapper">
     <div class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1 class="m-0 text-dark">Food</h1>
          </div><!-- /.col -->
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="<?php echo base_url('AdminDash');?>">Home</a></li>
              <li class="breadcrumb-item active">Food Add</li>
            </ol>
          </div>
        </div>
      </div>
    </div>
  
    <section class="col-lg-12 connectedSortable">
     <center><div class="col-lg-8">
         <div class="card-body login-card-body" style="border: 1px solid green;">
          <i class="nav-icon fab fa-audible"><h5 class="text-dark">Add Your<b>Description</b></h5></i> <br><br>
   <div class="row"> 
     <div class="col-sm-6">
      <label for="type_name" class="col-sm-6 "><span class="text-danger">*</span>Facility</label>
        <select name="facility" class="form-control">
          <option value="">select</option>
           <?php  $facility_values = array(
             'yes'=>'Yes',
             'no'=>'No',
                 );

        foreach($facility_values as $value => $display_text)
         {
            $selected = ($value == $this->input->post('facility')) ? ' selected="selected"' : "";
            echo '<option value="'.$value.'" '.$selected.'>'.$display_text.'</option>';
         } 
         ?>
      </select>
     </div>
     <div class="col-sm-6">
      <label for="type_name" class="col-sm-6 "><span class="text-danger">*</span>Decoration</label>
          <select name="decoration" class="form-control">
             <option value="">select</option>
                <?php $decoration_values = array(
                   'yes'=>'Yes',
                    'no'=>'No',
                  );
        foreach($decoration_values as $value => $display_text)
           {
               $selected = ($value == $this->input->post('decoration')) ? ' selected="selected"' : "";
               echo '<option value="'.$value.'" '.$selected.'>'.$display_text.'</option>';
            } 
        ?>
      </select>
     </div>
   </div>    <br>  
   <div class="row">  
     <div class="col-sm-6">
      <label for="type_name" class="col-sm-6 "><span class="text-danger">*</span>Setup</label>
        <select name="setup" class="form-control">
        <option value="">select</option>
        <?php 
        $setup_values = array(
          'yes'=>'Yes',
          'no'=>'No',
        );

        foreach($setup_values as $value => $display_text)
        {
          $selected = ($value == $this->input->post('setup')) ? ' selected="selected"' : "";

          echo '<option value="'.$value.'" '.$selected.'>'.$display_text.'</option>';
        } 
        ?>
      </select>
     </div>
     <div class="col-sm-6">
      <label for="type_name" class="col-sm-6 "><span class="text-danger">*</span>Types</label>
          <select name="types" class="form-control">
        <option value="">select</option>
        <?php 
        $types_values = array(
          'yes'=>'Yes',
          'no'=>'No',
        );

        foreach($types_values as $value => $display_text)
        {
          $selected = ($value == $this->input->post('types')) ? ' selected="selected"' : "";

          echo '<option value="'.$value.'" '.$selected.'>'.$display_text.'</option>';
        } 
        ?>
      </select>
     </div>
   </div>   <br/>
    <div class="row">  
     <div class="col-sm-6">
      <label for="type_name" class="col-sm-6 "><span class="text-danger">*</span>Food</label>
          <select name="food" class="form-control">
        <option value="">select</option>
        <?php 
        $food_values = array(
          'yes'=>'Yes',
          'no'=>'No',
        );

        foreach($food_values as $value => $display_text)
        {
          $selected = ($value == $this->input->post('food')) ? ' selected="selected"' : "";

          echo '<option value="'.$value.'" '.$selected.'>'.$display_text.'</option>';
        } 
        ?>
      </select>
     </div>
     <div class="col-sm-6">
      <label for="type_name" class="col-sm-6 "><span class="text-danger">*</span>Special</label>
         <select name="special" class="form-control">
        <option value="">select</option>
        <?php 
        $special_values = array(
          'yes'=>'Yes',
          'no'=>'No',
        );

        foreach($special_values as $value => $display_text)
        {
          $selected = ($value == $this->input->post('special')) ? ' selected="selected"' : "";

          echo '<option value="'.$value.'" '.$selected.'>'.$display_text.'</option>';
        } 
        ?>
      </select>
     </div>
   </div> <br>
    <div class="form-group">
            <label for="type_name" class="col-sm-6 float-sm-left"><span class="text-danger">*</span>Type Name</label>
            <div class="col-md-8">
                <input type="text" placeholder="vendor type" name="vendor_type" value="<?php echo $this->input->post('vendor_type'); ?>" class="form-control" id="vendor_type" />
            </div>
    </div>
    <div class="form-group">
      <div class="col-sm-offset-4 col-sm-8">
        <button type="submit" class="btn btn-success">Save</button>
      </div>
    </div>        
    </section>
  </div>
<?php echo form_close(); ?>   
