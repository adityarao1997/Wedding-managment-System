<?php defined('BASEPATH') OR exit('No direct script access allowed');?> 
<?php echo form_open('AdminDash/Special_Add',array("class"=>"form-horizontal")); ?>
 <?php if($error = $this->session->flashdata('login_response')):?>
      <div class="row">
        <div class="col-lg-12">
            <div class="alert alert-dismissible alert-danger">
               <?php echo $error; ?>
            </div>
       </div>
      </div>
    <?php endif; ?> 


 <div class="content-wrapper">
     <div class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1 class="m-0 text-dark">Special</h1>
          </div><!-- /.col -->
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="<?php echo base_url('AdminDash');?>">Home</a></li>
              <li class="breadcrumb-item active">Special Add</li>
            </ol>
          </div>
        </div>
      </div>
    </div>
  
    <section class="col-lg-12 connectedSortable">
     <center><div class="col-lg-6">
         <div class="card-body login-card-body" style="border: 1px solid green;">
          <i class="nav-icon fab fa-audible"><h5 class="text-dark">Select the <b>Speical type</b></h5></i> <br><br>
          <div class="form-group">
            <label for="type_name" class="col-sm-6 float-sm-left"><span class="text-danger">*</span>Select Spacial Type</label>
            <div class="col-md-8">
                <select name="vendor_typeid" class="form-control">
                      <option value="">select vendor_type</option>
                          <?php  foreach($all_vendor_type as $vendor_type)
                            {
                                 $selected = ($vendor_type['id'] == $this->input->post('vendor_typeid')) ? ' selected="selected"' : "";

                                 echo '<option value="'.$vendor_type['id'].'" '.$selected.'>'.$vendor_type['vendor_type'].'</option>';
                            } ?>
               </select>
            </div>
          </div>
         <div class="form-group">
            <label for="type_name" class="col-sm-6 float-sm-left"><span class="text-danger">*</span>Type Name</label>
            <div class="col-md-8">
               <input type="text" name="special_name" placeholder="Special NAme" value="<?php echo $this->input->post('special_name'); ?>" class="form-control" id="special_name" />
            </div>
        </div>
          <div class="form-group">
            <div class="col-sm-offset-4 col-sm-8">
                <button type="submit" class="btn btn-success">Save</button>
            </div>
           </div>
          </div>
        </div></center>    
    </section>
  </div>
<?php echo form_close(); ?>   
