<?php defined('BASEPATH') OR exit('No direct script access allowed');?> 
<body class="">


 
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <div class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1 class="m-0 text-dark"><strong>Vender </strong> List</h1>
          </div><!-- /.col -->
          <div class="col-sm-12 mt-3" style="background:#EAE7E7; height: 6vh;">
            <ol class="breadcrumb">
              <li class="breadcrumb-item"><a href="<?php echo base_url('AdminDash');?>">Home</a><i
              class="fas fa-angle-double-right mx-2 white-text" aria-hidden="true"></i></li>
              <li class="active"><strong>View All-Venders</strong></li>
            </ol>
          </div><!-- /.col -->
        </div><!-- /.row -->
      </div><!-- /.container-fluid -->
    </div>
    <!-- /.content-header -->

    <!-- Main content -->
    <section class="col-lg-12 connectedSortable">
      <div class="Container col-md-12">
         <?php echo form_open("AdminDash/");?>
          
           <div class="form-group col-md-8 row no-gutters">
              <div class="col">
                <?php echo form_input(['name' => 'query','class'=>'form-control', 'placeholder'=>'Search','value'=>set_value('')]);?>
             </div> 
            <div class="input-group-append mr-2">
                <div class="input-group-text">
                  <span class="fas fa-search"></span>
                </div>
            </div>
                      
             <div class="col-auto ml-5">
                  <?php echo form_submit(['value' => 'Add New','class'=>'btn btn-dark float-sm-right']);?>
             </div>            
                           
                        </div>
        
         
      <center><div class="Container col-md-12">
        <table class="table table-hover table-active" >
              <thead >
                    <tr>
                      <th scope="col">Serial</th>
                      <th scope="col">Bussiness Type</th>
                      <th scope="col">Comapny Name</th>
                      <th scope="col">Name</th>
                      <th scope="col">Email</th>
                      <th scope="col">Contact</th>
                      <th scope="col">City</th>
                      <th scope="col">Status</th>
                      <th scope="col">Edit</th>
                      <th scope="col">Reject</th>
                      
                    </tr>
             </thead>
            <tbody class="thead-light">
                <?php foreach($result as $res):?>
                  <tr>
                   <td><?php echo $res->id; ?></td>
                   <td><?php echo $res->vendor_type; ?></td>
                   <td><?php echo $res->company_name; ?></td>
                   <td><?php echo $res->owner_name; ?></td>
                   <td><?php echo $res->email_id; ?></td>
                   <td><?php echo $res->contact_no; ?></td>
                   <td><?php echo $res->city; ?></td>
                   <?php if($res->status == '0'):?>
                       <td style="color: red;"><?php echo "pendding"; ?></td>
                   <?php else: ?>
                   <?php if($res->status == '1'): ?>
                     <td style="color: green;"><?php echo "Active"; ?></td>
                   <?php endif;?>
                   <?php endif;?>
                  
                         <td>
                           <button class="btn btn-block btn-outline-danger">
                            <a href="<?php echo site_url('AdminDash/VenderEdit/'.$res->id); ?>">Edit</a> 
                             </button>
                          </td> 
                          <td>
                           <button class="btn btn-block btn-outline-danger">
                            <a href="<?php echo site_url('AdminDash/VenderRemove/'.$res->id); ?>">Delete</a> 
                             </button>
                          </td>
                      
                  </tr>
                 <?php endforeach; ?>
            </tbody>
       </table>
    </div></center>
      
         
                                    <!--      Close  -->
        
        </div>
    </section>
            
</div>