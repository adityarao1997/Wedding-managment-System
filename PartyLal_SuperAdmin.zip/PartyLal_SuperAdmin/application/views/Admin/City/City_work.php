<?php defined('BASEPATH') OR exit('No direct script access allowed');?> 
<body class="">


 
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <div class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1 class="m-0 text-dark">City</h1>
          </div><!-- /.col -->
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="#">Home</a></li>
              <li class="breadcrumb-item active">Dashboard</li>
            </ol>
          </div><!-- /.col -->
        </div><!-- /.row -->
      </div><!-- /.container-fluid -->
    </div>
      
      <section class="col-lg-12 connectedSortable">
        <div class="Container col-md-12">
         <?php echo form_open_multipart("AdminDash/AddCity" ,['class'=>'navbar-form navbar-right ','role'=>'search']);?>
         <div class="form-group col-md-4 ">
            <?php echo form_input(['name' => 'query','class'=>'form-control', 'placeholder'=>'Enter Email','value'=>set_value('username')]);?>
         </div>
         <div class="form-group col-md-4">
            <?php echo form_submit(['value' => 'search','class'=>'btn btn-primary']);?>
             <?php echo form_submit(['value' => 'Add New','class'=>'btn btn-primary float-sm-right']);?>
        </div>
           
       
     </div>
<table class="table table-hover table-active" >
  <thead style="background-color:#007bff; color: white; ">
    <tr>
      <th scope="col">Serial no.</th>
      <th scope="col">State</th>
      <th scope="col">City</th>
      <th scope="col">Image</th>
      <th scope="col">Delete</th>
    </tr>
  </thead>
  <tbody>
      <?php foreach($res as $r){ ?>
    <tr>
      <td><?php echo $r->id; ?></td>
      <td><?php echo $r->state; ?></td>
      <td><?php echo $r->city_name; ?></td>
      <td><img src="<?php echo base_url();?>prodimage/<?php echo $r->image;?>" style="width: 50px;"></td>
    
        <td>
         <button class="btn btn-block btn-outline-danger">
          <a href="<?php echo site_url('AdminDash/city_remove/'.$r->id); ?>">Delete</a> 
           </button>
        </td>
        
    </tr>
  <?php } ?>
  </tbody>
</table>
      </section>
    </div>