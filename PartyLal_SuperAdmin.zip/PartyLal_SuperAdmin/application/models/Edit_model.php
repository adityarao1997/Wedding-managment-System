<?php

  /**
     * 
     */
    class Edit_Model extends CI_Model
    {
    	
    	 function __construct()
         {
            parent::__construct();
         }
    
    /*
     * Get facility by id
     */
    function get_facility($id)
    {
        return $this->db->get_where('facilities',array('id'=>$id))->row_array();
    }
    /*
     * function to update facility
     */
    function update_facility($id,$params)
    {
        $this->db->where('id',$id);
        return $this->db->update('facilities',$params);
    }

    

    /*
     * Get vendor_type by id
     */
    function get_vendor_type($id)
    {
        return $this->db->get_where('vendor_type',array('id'=>$id))->row_array();
    }
    /*
     * function to update vendor_type
     */
    function update_vendor_type($id,$params)
    {
        $this->db->where('id',$id);
        return $this->db->update('vendor_type',$params);
    }
  
     
    /*
     * Get setup by id
     */
    function get_setup($id)
    {
        return $this->db->get_where('setup',array('id'=>$id))->row_array();
    }
    /*
     * function to update setup
     */
    function update_setup($id,$params)
    {
        $this->db->where('id',$id);
        return $this->db->update('setup',$params);
    }
    
    /*
     * Get special by id
     */
    function get_special($id)
    {
        return $this->db->get_where('special',array('id'=>$id))->row_array();
    }
    /*
     * function to update special
     */
    function update_special($id,$params)
    {
        $this->db->where('id',$id);
        return $this->db->update('special',$params);
    }


    /*
     * Get food by id
     */
    function get_food($id)
    {
        return $this->db->get_where('food',array('id'=>$id))->row_array();
    }
    /*
     * function to update food
     */
    function update_food($id,$params)
    {
        $this->db->where('id',$id);
        return $this->db->update('food',$params);
    }


    /*
     * Get decoration_type by id
     */
    function get_decoration_type($id)
    {
        return $this->db->get_where('decoration_type',array('id'=>$id))->row_array();
    }
    /*
     * function to update decoration_type
     */
    function update_decoration_type($id,$params)
    {
        $this->db->where('id',$id);
        return $this->db->update('decoration_type',$params);
    }
    
    /*
     * Get admin by id
     */
    function get_admin($id)
    {
        return $this->db->get_where('admin',array('id'=>$id))->row_array();
    }
    /*
     * function to update admin
     */
    function update_admin($id,$params)
    {
        $this->db->where('id',$id);
        return $this->db->update('admin',$params);
    }
    
    /*
     * Get Vender by id
     */
    function get_Vender($id)
    {
        return $this->db->get_where('vendors',array('id'=>$id))->row_array();
        
    }
    /*
     * function to update Vender
     */
    function update_Vender($id,$params)
    {
        $this->db->where('id',$id);
        return $this->db->update('vendors',$params);
    }
    
}?>