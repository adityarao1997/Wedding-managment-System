<?php 

    $this->load->view('Layout/include/header');
    $this->load->view('Layout/include/sidebar');
    $this->load->view('Admin/AdminList/AdminEditMain.php');
    $this->load->view('Layout/include/footer');


?>
