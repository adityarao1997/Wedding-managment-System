<?php 

    $this->load->view('Layout/include/header');
    $this->load->view('Layout/include/sidebar');
    $this->load->view('Admin/Facility/Edit_Facility.php');
    $this->load->view('Layout/include/footer');


?>