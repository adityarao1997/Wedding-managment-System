<?php defined('BASEPATH') OR exit('No direct script access allowed');?> 
 <div class="content-wrapper">

     <div class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1 class="m-0 text-dark">Food</h1>
          </div><!-- /.col -->
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="#">Home</a></li>
              <li class="breadcrumb-item active">Food type</li>
            </ol>
          </div><!-- /.col -->
        </div><!-- /.row -->
      </div><!-- /.container-fluid -->
    </div>
    <!-- /.content-header -->

    <!-- Main content -->
    <section class="col-lg-12 connectedSortable">
        <div class="Container col-md-12">
         <?php echo form_open("AdminDash/Food_add" ,['class'=>'navbar-form navbar-right ','role'=>'search']);?>
         <div class="form-group col-md-4 ">
            <?php echo form_input(['name' => 'query','class'=>'form-control', 'placeholder'=>'Enter Email','value'=>set_value('username')]);?>
         </div>
         <div class="form-group col-md-4">
            <?php echo form_submit(['value' => 'search','class'=>'btn btn-primary']);?>
             <?php echo form_submit(['value' => 'Add New','class'=>'btn btn-primary float-sm-right']);?>
        </div>
           
       
     </div>
     
     
    
   
     <table class="table table-hover table-active" >
  <thead style="background-color:#007bff; color: white; ">
    <tr>
     <!--  <th scope="col">ID</th> -->
      <th scope="col">Food Typeid</th>
      <th scope="col">Type Name</th>
      <th scope="col">Edit</th>
      <th scope="col">Delete</th>
    </tr>
  </thead>
  <tbody>
  <?php foreach($food as $f){ ?>
    <tr>
   <!--  <td><?php //echo $f['id']; ?></td> -->
    <td><?php echo $f['vendor_typeid']; ?></td>
    <td><?php echo $f['food_name']; ?></td>
  
    
            <td>
             <button class="btn btn-block btn-outline-info">
               <a href="<?php echo site_url('AdminDash/Food_Edit/'.$f['id']); ?>">Edit</a> 
               </button>
            </td>
            <td>
             <button class="btn btn-block btn-outline-danger">
              <a href="<?php echo site_url('AdminDash/Food_remove/'.$f['id']); ?>">Delete</a> 
               </button>
            </td>
        
    </tr>
  <?php } ?>
  </tbody>
</table>
<!-- <div class="pull-right">
    <?php// echo $this->pagination->create_links(); ?>    
</div>
 -->
  </section>
 </div>    
