<?php 

    $this->load->view('Layout/include/header');
    $this->load->view('Layout/include/sidebar');
    $this->load->view('Admin/VenderTypes-f/Vendor_typeMain.php');
    $this->load->view('Layout/include/footer');


?>






