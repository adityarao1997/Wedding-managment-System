<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Dashboard extends CI_Controller {

	/**
	 *  Index Page for this controller.
	 */
    
    function __construct()
    {
        parent::__construct();
        $this->load->model('Admin_model');
                
    }
   /*
    *  Dashboard Index
    */
    function index()
    {
       if(!$this->session->userdata('id'))
         {
            return redirect('Login');
         }else{
                  $data['_view'] =  'SubAdmin/Dashboard/index';
                  $this->load->view('SubAdmin/Dashboard/index',$data);
              }
             
    }
}