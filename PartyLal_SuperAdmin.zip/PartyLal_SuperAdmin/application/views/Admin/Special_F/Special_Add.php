<?php 

    $this->load->view('Layout/include/header');
    $this->load->view('Layout/include/sidebar');
    $this->load->view('Admin/Special_F/Special_AddMain.php');
    $this->load->view('Layout/include/footer');


?>






