-- phpMyAdmin SQL Dump
-- version 4.9.0.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jan 16, 2020 at 11:50 AM
-- Server version: 10.3.16-MariaDB
-- PHP Version: 7.1.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `partylal`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `id` int(11) NOT NULL,
  `role` varchar(20) NOT NULL,
  `name` varchar(250) NOT NULL,
  `email` varchar(250) NOT NULL,
  `contact` varchar(250) NOT NULL,
  `password` varchar(500) NOT NULL,
  `last_login` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `last_loginip` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`id`, `role`, `name`, `email`, `contact`, `password`, `last_login`, `last_loginip`) VALUES
(1, 'SuperAdmin', 'Prabhakar', 'wassupprabhakar@gmail.com', '789456123', '1234567P', '2020-01-15 18:30:00', 'X'),
(2, 'ADMIN', 'Aditya Rao', 'aditya@info.com', '789456321', '1234567a', '2020-01-15 18:30:00', 'qq');

-- --------------------------------------------------------

--
-- Table structure for table `decoration_type`
--

CREATE TABLE `decoration_type` (
  `id` int(11) NOT NULL,
  `decoration_name` varchar(250) NOT NULL,
  `vendor_typeid` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `decoration_type_available`
--

CREATE TABLE `decoration_type_available` (
  `id` int(11) NOT NULL,
  `decoration_name` varchar(250) NOT NULL,
  `vendor_id` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `experties`
--

CREATE TABLE `experties` (
  `id` int(11) NOT NULL,
  `rank` varchar(2) NOT NULL,
  `type` varchar(100) NOT NULL,
  `experience` varchar(500) NOT NULL,
  `vendor_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `facilities`
--

CREATE TABLE `facilities` (
  `id` int(11) NOT NULL,
  `facility_name` varchar(250) NOT NULL,
  `vendor_typeid` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `facilities`
--

INSERT INTO `facilities` (`id`, `facility_name`, `vendor_typeid`) VALUES
(1, 'aditya', 1);

-- --------------------------------------------------------

--
-- Table structure for table `facility_available`
--

CREATE TABLE `facility_available` (
  `id` int(11) NOT NULL,
  `facility` varchar(250) NOT NULL,
  `vendor_id` int(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `food`
--

CREATE TABLE `food` (
  `id` int(11) NOT NULL,
  `food_name` varchar(250) NOT NULL,
  `vendor_typeid` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `food_available`
--

CREATE TABLE `food_available` (
  `id` int(11) NOT NULL,
  `food_name` varchar(250) NOT NULL,
  `vendor_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `package`
--

CREATE TABLE `package` (
  `id` int(11) NOT NULL,
  `package_no` int(10) NOT NULL,
  `package_cat` varchar(100) NOT NULL,
  `image` varchar(500) NOT NULL,
  `package_name` varchar(250) NOT NULL,
  `price` varchar(20) NOT NULL,
  `vendor_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `package_items`
--

CREATE TABLE `package_items` (
  `id` int(11) NOT NULL,
  `item_name` varchar(250) NOT NULL,
  `cost` varchar(10) NOT NULL,
  `package_id` int(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `setup`
--

CREATE TABLE `setup` (
  `id` int(11) NOT NULL,
  `setup_name` varchar(250) NOT NULL,
  `vendor_typeid` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `setup_available`
--

CREATE TABLE `setup_available` (
  `id` int(11) NOT NULL,
  `setup_name` varchar(250) NOT NULL,
  `vendor_id` int(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `specail_values`
--

CREATE TABLE `specail_values` (
  `id` int(11) NOT NULL,
  `special_name` varchar(250) NOT NULL,
  `special_id` int(11) NOT NULL,
  `special_value` varchar(250) NOT NULL,
  `vendor_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `special`
--

CREATE TABLE `special` (
  `id` int(11) NOT NULL,
  `special_name` varchar(250) NOT NULL,
  `vendor_typeid` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `types`
--

CREATE TABLE `types` (
  `id` int(11) NOT NULL,
  `type_name` varchar(250) NOT NULL,
  `vendor_typeid` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `type_available`
--

CREATE TABLE `type_available` (
  `id` int(11) NOT NULL,
  `type_name` varchar(250) NOT NULL,
  `vendor_id` int(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `vendors`
--

CREATE TABLE `vendors` (
  `id` int(11) NOT NULL,
  `vendor_typeid` int(11) NOT NULL,
  `company_name` int(250) NOT NULL,
  `owner_name` varchar(250) NOT NULL,
  `contact_no` varchar(20) NOT NULL,
  `email_id` varchar(250) NOT NULL,
  `password` varchar(500) NOT NULL,
  `address` varchar(500) NOT NULL,
  `city` varchar(150) NOT NULL,
  `team_size` int(4) NOT NULL,
  `minimum_order_value` varchar(20) NOT NULL,
  `customer_perday` int(4) NOT NULL,
  `offers` varchar(500) NOT NULL,
  `addvance_required` varchar(10) NOT NULL,
  `cancellation_charge` varchar(10) NOT NULL,
  `food_available` varchar(10) NOT NULL,
  `decoration_typeavailable` varchar(10) NOT NULL,
  `music_available` varchar(10) NOT NULL,
  `alcohal` varchar(10) NOT NULL,
  `perpeg_cost` varchar(10) NOT NULL,
  `living_room` varchar(10) NOT NULL,
  `room_cost` varchar(10) NOT NULL,
  `parking` varchar(10) NOT NULL,
  `service_area` varchar(100) NOT NULL,
  `service_option` varchar(100) NOT NULL,
  `equipments` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `vendor_type`
--

CREATE TABLE `vendor_type` (
  `id` int(11) NOT NULL,
  `vendor_type` varchar(250) NOT NULL,
  `facility` varchar(3) NOT NULL,
  `decoration` varchar(3) NOT NULL,
  `setup` varchar(3) NOT NULL,
  `types` varchar(3) NOT NULL,
  `food` varchar(3) NOT NULL,
  `special` varchar(3) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `vendor_type`
--

INSERT INTO `vendor_type` (`id`, `vendor_type`, `facility`, `decoration`, `setup`, `types`, `food`, `special`) VALUES
(1, 'Vxxxxxxxx', 'yes', 'yes', 'yes', 'yes', 'yes', 'yes');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `decoration_type`
--
ALTER TABLE `decoration_type`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `decoration_type_available`
--
ALTER TABLE `decoration_type_available`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `experties`
--
ALTER TABLE `experties`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `facilities`
--
ALTER TABLE `facilities`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `facility_available`
--
ALTER TABLE `facility_available`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `food`
--
ALTER TABLE `food`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `food_available`
--
ALTER TABLE `food_available`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `package`
--
ALTER TABLE `package`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `package_items`
--
ALTER TABLE `package_items`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `setup`
--
ALTER TABLE `setup`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `specail_values`
--
ALTER TABLE `specail_values`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `special`
--
ALTER TABLE `special`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `types`
--
ALTER TABLE `types`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `vendors`
--
ALTER TABLE `vendors`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `vendor_type`
--
ALTER TABLE `vendor_type`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `decoration_type`
--
ALTER TABLE `decoration_type`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `decoration_type_available`
--
ALTER TABLE `decoration_type_available`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `experties`
--
ALTER TABLE `experties`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `facilities`
--
ALTER TABLE `facilities`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `facility_available`
--
ALTER TABLE `facility_available`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `food`
--
ALTER TABLE `food`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `food_available`
--
ALTER TABLE `food_available`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `package`
--
ALTER TABLE `package`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `package_items`
--
ALTER TABLE `package_items`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `setup`
--
ALTER TABLE `setup`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `specail_values`
--
ALTER TABLE `specail_values`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `special`
--
ALTER TABLE `special`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `vendors`
--
ALTER TABLE `vendors`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `vendor_type`
--
ALTER TABLE `vendor_type`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
