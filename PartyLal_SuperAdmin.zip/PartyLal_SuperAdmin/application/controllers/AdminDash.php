<?php

  /**
   * 
   */
  class AdminDash extends CI_Controller
  {
  	function __construct()
    {
        parent::__construct();
        $this->load->model('SAdmin_model');
        $this->load->model('Remove_model');
        $this->load->model('Edit_model');
    } 

    /*
     * Listing of types
     */
  	  function index()
  	  {
  	  	
  	     if(!$this->session->userdata('id')){
                  return redirect('Login');
            }else{
                $this->load->view('Admin/Dashboard/index');
              }
      }

      function Admin()
      {
          
          
        $this->load->model('SAdmin_model');
        $result = $this->SAdmin_model->get_all_admin();
        $this->load->view('Admin/AdminList/Admin',['result' => $result]);
      }
      function AddAdmin()
      {
        
        $data['_view'] = 'Admin/AdminList/AdminAdd';
        $this->load->view('Admin/AdminList/AdminAdd',$data);
      }//super Admin Create
      function Vender()
      {    
        $this->load->model('SAdmin_model');
        $result = $this->SAdmin_model->get_all_vender();
        $this->load->view('Admin/VenderList/VenderView.php',['result' => $result]);
      }
       function Types()
       {   
         
         $data['types'] = $this->SAdmin_model->get_all_vendertype();
        
        $data['_view'] = 'Admin/Types-f/Types';
        $this->load->view('Admin/Types-f/Types',$data);
        } 

      function TypesAdd()
       {   
        $this->load->library('form_validation');
        $this->form_validation->set_rules('vendor_typeid','Vendor Typeid','required');
        $this->form_validation->set_rules('type_name','Type Name','required');
        $this->form_validation->set_error_delimiters('<div class="text-danger">','</div>');
         if($this->form_validation->run())     
           {   
                 $params = array(
                   'vendor_typeid' => $this->input->post('vendor_typeid'),
                   'type_name' => $this->input->post('type_name'),
                  );
            
              $type_id = $this->SAdmin_model->add_Vendertype($params);
              redirect('AdminDash/Types');
          }else{
  
                 $this->load->model('SAdmin_model');
                 $data['all_vendor_type'] = $this->SAdmin_model->get_all_vendor_type();
            
                 $data['_view'] = 'Admin/Types-f/TypesAdd';
                 $this->load->view('Admin/Types-f/TypesAdd',$data);
        }
    }  

    function Food()
    {
        $params['limit'] = 'RECORDS_PER_PAGE'; 
        $params['offset'] = ($this->input->get('per_page')) ? $this->input->get('per_page') : 0;
        
        $config = $this->config->item('pagination');
        $config['base_url'] = site_url('Admin/Food_F/Food_type');
        $config['total_rows'] = $this->SAdmin_model->get_all_food_count();
        $this->pagination->initialize($config);

        $data['food'] = $this->SAdmin_model->get_all_food($params);
        
        $data['_view'] = 'Admin/Food_F/Food';
        $this->load->view('Admin/Food_F/Food',$data);

    }
     /*
     * Adding a new food
     */
     function Food_add()
    {   
       $this->load->library('form_validation');

    $this->form_validation->set_rules('vendor_typeid','Vendor Typeid','required');
    $this->form_validation->set_rules('food_name','Food Name','required');
    
    if($this->form_validation->run())     
        {   
            $params = array(
                 'vendor_typeid' => $this->input->post('vendor_typeid'),
                  'food_name' => $this->input->post('food_name'),
            );
            
                   $food_id = $this->SAdmin_model->add_food($params);
                     redirect('AdminDash/Food');
        }
        else
        {
              $this->load->model('SAdmin_model');
               $data['all_vendor_type'] = $this->SAdmin_model->get_all_vendor_type();
            
            $data['_view'] = 'Admin/Food_F/Food_add';
            $this->load->view('Admin/Food_F/Food_add',$data);
        }

    } 

    function vendor_type()
    {
        $params['limit'] = 'RECORDS_PER_PAGE'; 
        $params['offset'] = ($this->input->get('per_page')) ? $this->input->get('per_page') : 0;
        
        $config = $this->config->item('pagination');
        $config['base_url'] = site_url('Admin/VenderTypes-f/Vendor_type?');
        $config['total_rows'] = $this->SAdmin_model->get_all_vendor_count();
        $this->pagination->initialize($config);

        $data['vendor_type'] = $this->SAdmin_model->get_all_vendor($params);
        
        $data['_view'] = 'Admin/VenderTypes-f/Vendor_type';
        $this->load->view('Admin/VenderTypes-f/Vendor_type',$data);
    } 
    function Addvender_type(){

      $this->load->library('form_validation');

    $this->form_validation->set_rules('vendor_type','Vendor Type','required');
    $this->form_validation->set_rules('facility','Facility','required');
    $this->form_validation->set_rules('decoration','Decoration','required');
    $this->form_validation->set_rules('setup','Setup','required');
    $this->form_validation->set_rules('types','Types','required');
    $this->form_validation->set_rules('food','Food','required');
    $this->form_validation->set_rules('special','Special','required');
    
    if($this->form_validation->run())     
        {   
            $params = array(
        'facility' => $this->input->post('facility'),
        'decoration' => $this->input->post('decoration'),
        'setup' => $this->input->post('setup'),
        'types' => $this->input->post('types'),
        'food' => $this->input->post('food'),
        'special' => $this->input->post('special'),
        'vendor_type' => $this->input->post('vendor_type'),
            );
            
            $vendor_type_id = $this->SAdmin_model->add_vendor_type($params);
            redirect('AdminDash/vendor_type');
        }
        else
        {            
            $data['_view'] = 'Admin/VenderTypes-f/Addvender_type';
            $this->load->view('Admin/VenderTypes-f/Addvender_type',$data);
        }
    }

   function Facility(){
   
        $params['limit'] = 'RECORDS_PER_PAGE'; 
        $params['offset'] = ($this->input->get('per_page')) ? $this->input->get('per_page') : 0;
        
        $config = $this->config->item('pagination');
        $config['base_url'] = site_url('Admin/Facility?');
        $config['total_rows'] = $this->SAdmin_model->get_all_facilities_count();
        $this->pagination->initialize($config);

        $data['facilities'] = $this->SAdmin_model->get_all_facilities($params);
        
        $data['_view'] = 'Admin/Facility/Facility';
        $this->load->view('Admin/Facility/Facility',$data);

   }
   function AddFacility()
   {
      $this->load->library('form_validation');

    $this->form_validation->set_rules('vendor_typeid','Vendor Typeid','required');
    $this->form_validation->set_rules('facility_name','Facility Name','required');
    
    if($this->form_validation->run())     
        {   
            $params = array(
        'vendor_typeid' => $this->input->post('vendor_typeid'),
        'facility_name' => $this->input->post('facility_name'),
            );
            
            $facility_id = $this->SAdmin_model->add_facility($params);
            redirect('AdminDash/Facility');
        }
        else
        {
      $this->load->model('SAdmin_model');
      $data['all_vendor_type'] = $this->SAdmin_model->get_all_vendor_type();
            
            $data['_view'] = 'Admin/Facility/AddFacility';
            $this->load->view('Admin/Facility/AddFacility',$data);
        }
   }

   
   function Setup(){

        $params['limit'] = 'RECORDS_PER_PAGE'; 
        $params['offset'] = ($this->input->get('per_page')) ? $this->input->get('per_page') : 0;
        
        $config = $this->config->item('pagination');
        $config['base_url'] = site_url('setup/Setup_F/Setup?');
        $config['total_rows'] = $this->SAdmin_model->get_all_setup_count();
        $this->pagination->initialize($config);

        $data['setup'] = $this->SAdmin_model->get_all_setup($params);
        
        $data['_view'] = 'Admin/Setup_F/Setup';
        $this->load->view('Admin/Setup_F/Setup',$data);
   }

   function Add_Setup(){

    $this->load->library('form_validation');

    $this->form_validation->set_rules('vendor_typeid','Vendor Typeid','required');
    $this->form_validation->set_rules('setup_name','Setup Name','required');
    
    if($this->form_validation->run())     
        {   
            $params = array(
        'vendor_typeid' => $this->input->post('vendor_typeid'),
        'setup_name' => $this->input->post('setup_name'),
            );
            
            $setup_id = $this->SAdmin_model->add_setup($params);
            redirect('AdminDash/Setup');
        }
        else
        {
      $this->load->model('SAdmin_model');
      $data['all_vendor_type'] = $this->SAdmin_model->get_all_vendor_type();
            
            $data['_view'] = 'Admin/Setup_F/Add_Setup';
            $this->load->view('Admin/Setup_F/Add_Setup',$data);
        }
   }

   function Deco(){

        $params['limit'] = 'RECORDS_PER_PAGE'; 
        $params['offset'] = ($this->input->get('per_page')) ? $this->input->get('per_page') : 0;
        
        $config = $this->config->item('pagination');
        $config['base_url'] = site_url('Admin/Decoration_F/Deco?');
        $config['total_rows'] = $this->SAdmin_model->get_all_decoration_type_count();
        $this->pagination->initialize($config);

        $data['decoration_type'] = $this->SAdmin_model->get_all_decoration_type($params);
        
        $data['_view'] = 'Admin/Decoration_F/Deco';
        $this->load->view('Admin/Decoration_F/Deco',$data);
   }

   function AddDecoration(){

    $this->load->library('form_validation');

    $this->form_validation->set_rules('decoration_name','Decoration Name','required');
    $this->form_validation->set_rules('vendor_typeid','Vendor Typeid','required');
    
    if($this->form_validation->run())     
        {   
            $params = array(
        'vendor_typeid' => $this->input->post('vendor_typeid'),
        'decoration_name' => $this->input->post('decoration_name'),
            );
            
            $decoration_type_id = $this->SAdmin_model->add_decoration_type($params);
            redirect('AdminDash/Deco');
        }
        else
        {
            
            $data['all_vendor_type'] = $this->SAdmin_model->get_all_vendor_type();
            
            $data['_view'] = 'Admin/Decoration_F/AddDeco.php';
            $this->load->view('Admin/Decoration_F/AddDeco.php',$data);
        }
   }


   /*
     * Listing of special
     */
    function Special()
    {
        $params['limit'] = 'RECORDS_PER_PAGE'; 
        $params['offset'] = ($this->input->get('per_page')) ? $this->input->get('per_page') : 0;
        
        $config = $this->config->item('pagination');
        $config['base_url'] = site_url('Admin/Special_F/Special?');
        $config['total_rows'] = $this->SAdmin_model->get_all_special_count();
        $this->pagination->initialize($config);

        $data['special'] = $this->SAdmin_model->get_all_special($params);
        
        $data['_view'] = 'Admin/Special_F/Special';
        $this->load->view('Admin/Special_F/Special',$data);
    }

    /*
     * Adding a new special
     */
    function Special_Add()
    {   
        $this->load->library('form_validation');

       $this->form_validation->set_rules('special_name','Special Name','required');
       $this->form_validation->set_rules('vendor_typeid','Vendor Typeid','required');
    
    if($this->form_validation->run())     
        {   
            $params = array(
        'vendor_typeid' => $this->input->post('vendor_typeid'),
        'special_name' => $this->input->post('special_name'),
            );
            
            $special_id = $this->SAdmin_model->add_special($params);
            redirect('AdminDash/Special');
        }
        else
        {
      $this->load->model('SAdmin_model');
      $data['all_vendor_type'] = $this->SAdmin_model->get_all_vendor_type();
            
            $data['_view'] = 'Admin/Special_F/Special_Add';
            $this->load->view('Admin/Special_F/Special_Add',$data);
        }
    } 
      
    function ViewPackage()
    {
            $data['_view'] = 'Admin/Package_F/package.php';
            $this->load->view('Admin/Package_F/package.php',$data);
    }  
    function City()
    {
            $res= $this->SAdmin_model->Show(); 
            $w= array(
                  'res' => $res
              );
            $this->load->view('Admin/City/City.php',$w);
    }
    function AddCity()
    {  
            $config['upload_path'] = './prodimage/';
            $config['allowed_types'] = 'gif|jpg|png';
            $config['max_size']     = '100';
            $this->load->library('upload', $config);
            if(!$this->upload->do_upload('image'))
            {
               print_r("dfdgf");
            }else
            {
                $fd=$this->upload->data();
                
                $fn = $fd['file_name'];
                $this->SAdmin_model->cityaddModel($fn);
                return redirect('AdminDash/City');
            }
            $this->load->view('Admin/City/CityAdd.php');
            
    }

   // -----------------------------------Remove Function Start---------------------------------------- 

    /*
     * Deleting vendor_type
     */
    function Vendor_type_remove($id)
    {
        $vendor_type = $this->Remove_model->get_vendor_type($id);

        // check if the vendor_type exists before trying to delete it
        if(isset($vendor_type['id']))
        {
            $this->Remove_model->delete_vendor_type($id);
            redirect('AdminDash/vendor_type');
        }
        else
            show_error('The vendor_type you are trying to delete does not exist.');
    }

    /*
     * Deleting food
     */
    function Food_remove($id)
    {
        $food = $this->Remove_model->get_food($id);

        // check if the food exists before trying to delete it
        if(isset($food['id']))
        {
            $this->Remove_model->delete_food($id);
            redirect('AdminDash/Food');
        }
        else
            show_error('The food you are trying to delete does not exist.');
    }
    /*
     * Deleting vendor
     */
    function Vender_remove($id)
    {
        $vendor = $this->Remove_model->get_vendor($id);

        // check if the vendor exists before trying to delete it
        if(isset($vendor['id']))
        {
            $this->Remove_model->delete_vendor($id);
            redirect('AdminDash/Vendor');
        }
        else
            show_error('The vendor you are trying to delete does not exist.');
    }

    /*
     * Deleting facility
     */
    function Facility_remove($id)
    {
        $facility = $this->Remove_model->get_facility($id);

        // check if the facility exists before trying to delete it
        if(isset($facility['id']))
        {
            $this->Remove_model->delete_facility($id);
            redirect('AdminDash/Facility');
        }
        else
            show_error('The facility you are trying to delete does not exist.');
    }

    /*
     * Deleting setup
     */
    function Setup_remove($id)
    {
        $setup = $this->Remove_model->get_setup($id);

        // check if the setup exists before trying to delete it
        if(isset($setup['id']))
        {
            $this->Remove_model->delete_setup($id);
            redirect('AdminDash/Setup');
        }
        else
            show_error('The setup you are trying to delete does not exist.');
    }
    
     /*
     * Deleting decoration_type
     */
    function Deco_remove($id)
    {
        $decoration_type = $this->Remove_model->get_decoration_type($id);

        // check if the decoration_type exists before trying to delete it
        if(isset($decoration_type['id']))
        {
            $this->Remove_model->delete_decoration_type($id);
            redirect('AdminDash/Deco');
        }
        else
            show_error('The decoration_type you are trying to delete does not exist.');
    }

     /*
     * Deleting special
     */
    function Special_remove($id)
    {
        $special = $this->Remove_model->get_special($id);

        // check if the special exists before trying to delete it
        if(isset($special['id']))
        {
            $this->Remove_model->delete_special($id);
            redirect('AdminDash/Special');
        }
        else
            show_error('The special you are trying to delete does not exist.');
    }
    /*
     * Deleting type
     */
    function Type_remove($id)
    {
        $type = $this->Remove_model->get_type($id);

        // check if the type exists before trying to delete it
        if(isset($type['id']))
        {
            $this->Remove_model->delete_type($id);
            redirect('AdminDash/Types');
        }
        else
            show_error('The type you are trying to delete does not exist.');
    }
    function city_remove($id)
    {
        $city = $this->Remove_model->get_city($id);

        // check if the type exists before trying to delete it
        if(isset($city['id']))
        {
            $this->Remove_model->delete_city($id);
            redirect('AdminDash/City');
        }
        else
            show_error('The type you are trying to delete does not exist.');
    }
 

  // -----------------------------------Edit Function Start---------------------------------------- 
     

     
    /*
     * Editing a facility
     */
    function Face_Edit($id)
    {
       // check if the facility exists before trying to edit it
        $data['facility'] = $this->Edit_model->get_facility($id);
        
        if(isset($data['facility']['id']))
        {
            $this->load->library('form_validation');

      $this->form_validation->set_rules('vendor_typeid','Vendor Typeid','required');
      $this->form_validation->set_rules('facility_name','Facility Name','required');
    
      if($this->form_validation->run())     
            {   
                $params = array(
          'vendor_typeid' => $this->input->post('vendor_typeid'),
          'facility_name' => $this->input->post('facility_name'),
                );

                $this->Edit_model->update_facility($id,$params);            
                redirect('AdminDash/Facility');
            }
            else
            {
            
                $data['all_vendor_type'] = $this->SAdmin_model->get_all_vendor_type();

                $data['_view'] = 'Admin/Facility/Face_Edit';
                $this->load->view('Admin/Facility/Face_Edit',$data);
            }
        }
        else
            show_error('The facility you are trying to edit does not exist.');
    }
 
    function Type_edit($id)
    {   
        // check if the type exists before trying to edit it
        $data['type'] = $this->SAdmin_model->get_type($id);
           $data['all_vendor_type'] = $this->SAdmin_model->get_all_vendor_type();

        
        if(isset($data['type']['id']))
        {
            $this->load->library('form_validation');
      
       $this->form_validation->set_rules('vendor_typeid','Vendor Typeid','required');
      $this->form_validation->set_rules('type_name','Type Name','required');
    
      if($this->form_validation->run())     
            {   
                $params = array(
          'vendor_typeid' => $this->input->post('vendor_typeid'),
          'type_name' => $this->input->post('type_name'),
                );
                 
                $this->SAdmin_model->update_type($id,$params);
                  redirect('AdminDash/Types');
                
            }
            else
            {
               
            
                $data['_view'] = 'Admin/Types-f/TypeEdit';
                $this->load->view('Admin/Types-f/TypeEdit',$data);
            }
        }
        else
            show_error('The type you are trying to edit does not exist.');
    } 

  
     function VendorType_edit($id)
    {   
       
        $data['vendor_type'] = $this->Edit_model->get_vendor_type($id);
        
        if(isset($data['vendor_type']['id']))
        {
            $this->load->library('form_validation');

      $this->form_validation->set_rules('vendor_type','Vendor Type','required');
      $this->form_validation->set_rules('facility','Facility','required');
      $this->form_validation->set_rules('decoration','Decoration','required');
      $this->form_validation->set_rules('setup','Setup','required');
      $this->form_validation->set_rules('types','Types','required');
      $this->form_validation->set_rules('food','Food','required');
      $this->form_validation->set_rules('special','Special','required');
    
      if($this->form_validation->run())     
            {   
                $params = array(
          'facility' => $this->input->post('facility'),
          'decoration' => $this->input->post('decoration'),
          'setup' => $this->input->post('setup'),
          'types' => $this->input->post('types'),
          'food' => $this->input->post('food'),
          'special' => $this->input->post('special'),
          'vendor_type' => $this->input->post('vendor_type'),
                );

                $this->Edit_model->update_vendor_type($id,$params);            
                redirect('AdminDash/vendor_type');
            }
            else
            {
                $this->load->model('SAdmin_model');
                $data['all_vendor_type'] = $this->SAdmin_model->get_all_vendor_type();

                $data['_view'] = 'Admin/VenderTypes-f/Vendor_typeEdit';
                $this->load->view('Admin/VenderTypes-f/Vendor_typeEdit',$data);
            }
        }
        else
            show_error('The vendor_type you are trying to edit does not exist.');
    } 

    /*
     * Editing a setup
     */
    function SetupEdit($id)
    {   
        // check if the setup exists before trying to edit it
        $data['setup'] = $this->Edit_model->get_setup($id);
        
        if(isset($data['setup']['id']))
        {
            $this->load->library('form_validation');

      $this->form_validation->set_rules('vendor_typeid','Vendor Typeid','required');
      $this->form_validation->set_rules('setup_name','Setup Name','required');
    
      if($this->form_validation->run())     
            {   
                $params = array(
          'vendor_typeid' => $this->input->post('vendor_typeid'),
          'setup_name' => $this->input->post('setup_name'),
                );

                $this->Edit_model->update_setup($id,$params);            
                redirect('AdminDash/Setup');
            }
            else
            {
        $this->load->model('SAdmin_model');
        $data['all_vendor_type'] = $this->SAdmin_model->get_all_vendor_type();

                $data['_view'] = 'Admin/Setup_F/SetupEdit';
                $this->load->view('Admin/Setup_F/SetupEdit',$data);
            }
        }
        else
            show_error('The setup you are trying to edit does not exist.');
    } 

    /*
     * Editing a special
     */
    function SpecialEdit($id)
    {   
        // check if the special exists before trying to edit it
        $data['special'] = $this->Edit_model->get_special($id);
        
        if(isset($data['special']['id']))
        {
            $this->load->library('form_validation');

      $this->form_validation->set_rules('special_name','Special Name','required');
      $this->form_validation->set_rules('vendor_typeid','Vendor Typeid','required');
    
      if($this->form_validation->run())     
            {   
                $params = array(
          'vendor_typeid' => $this->input->post('vendor_typeid'),
          'special_name' => $this->input->post('special_name'),
                );

                $this->Edit_model->update_special($id,$params);            
                redirect('AdminDash/Special');
            }
            else
            {
        $this->load->model('SAdmin_model');
        $data['all_vendor_type'] = $this->SAdmin_model->get_all_vendor_type();

                $data['_view'] = 'Admin/Special_F/SpecialEdit';
                $this->load->view('Admin/Special_F/SpecialEdit',$data);
            }
        }
        else
            show_error('The special you are trying to edit does not exist.');
    } 
   
   /*
     * Editing a food
     */
    function Food_Edit($id)
    {   
        // check if the food exists before trying to edit it
        $data['food'] = $this->Edit_model->get_food($id);
        
        if(isset($data['food']['id']))
        {
            $this->load->library('form_validation');

      $this->form_validation->set_rules('vendor_typeid','Vendor Typeid','required');
      $this->form_validation->set_rules('food_name','Food Name','required');
    
      if($this->form_validation->run())     
            {   
                $params = array(
          'vendor_typeid' => $this->input->post('vendor_typeid'),
          'food_name' => $this->input->post('food_name'),
                );

                $this->Edit_model->update_food($id,$params);            
                redirect('AdminDash/Food');
            }
            else
            {
        $this->load->model('SAdmin_model');
        $data['all_vendor_type'] = $this->SAdmin_model->get_all_vendor_type();

                $data['_view'] = 'Admin/Food_F/FoodEdit';
                $this->load->view('Admin/Food_F/FoodEdit',$data);
            }
        }
        else
            show_error('The food you are trying to edit does not exist.');
    }
        /*
     * Editing a decoration_type
     */
    function Deco_edit($id)
    {   
        // check if the decoration_type exists before trying to edit it
        $data['decoration_type'] = $this->Edit_model->get_decoration_type($id);
        
        if(isset($data['decoration_type']['id']))
        {
            $this->load->library('form_validation');

      $this->form_validation->set_rules('decoration_name','Decoration Name','required');
      $this->form_validation->set_rules('vendor_typeid','Vendor Typeid','required');
    
      if($this->form_validation->run())     
            {   
                $params = array(
          'vendor_typeid' => $this->input->post('vendor_typeid'),
          'decoration_name' => $this->input->post('decoration_name'),
                );

                $this->Edit_model->update_decoration_type($id,$params);            
                redirect('AdminDash/Deco');
            }
            else
            {
     
               $data['all_vendor_type'] = $this->SAdmin_model->get_all_vendor_type();

                $data['_view'] = 'Admin/Decoration_F/DecoEdit.php';
                $this->load->view('Admin/Decoration_F/DecoEdit.php',$data);
            }
        }
        else
            show_error('The decoration_type you are trying to edit does not exist.');
    } 
   /*
    *
    */
    function AdminEdit1($id)
    {
           $data['result'] = $this->Edit_model->get_admin($id);
        
        if(isset($data['result']['id']))
        {
            $this->load->library('form_validation');

			$this->form_validation->set_rules('name','Name','required');
			$this->form_validation->set_rules('email','Email','required|valid_email');
			$this->form_validation->set_rules('contact','Contact','required|numeric|exact_length[10]');
			$this->form_validation->set_rules('password','Password','required|alpha_numeric');
            $this->form_validation->set_rules('city','City','required');
			$this->form_validation->set_rules('status','status','required'); 
		
			if($this->form_validation->run())     
            {   
                $params = array(
					'name' => $this->input->post('name'),
					'email' => $this->input->post('email'),
					'contact' => $this->input->post('contact'),
					'password' => $this->input->post('password'),
					'city' => $this->input->post('city'),
                    'status' => $this->input->post('status'),
                );
                
                $this->Edit_model->update_admin($id,$params);            
                redirect('AdminDash/Admin');
            }
            else
            {
                $data['_view'] = 'Admin/AdminList/AdminEdit.php';
                $this->load->view('Admin/AdminList/AdminEdit.php',$data);
            }
        }
        else
          {      
            show_error('The admin you are trying to edit does not exist.');
          }
    }
    /*
     * Deleting admin
     */
    function AdminRemove($id)
    {
        $result = $this->Remove_model->get_admin($id);

        // check if the admin exists before trying to delete it
        if(isset($result['id']))
        {
            $this->Remove_model->delete_admin($id);
            redirect('AdminDash/Admin');
        }
        else
            show_error('The admin you are trying to delete does not exist.');
    }
    
    /*
     *   Edit Vender
     */
    function VenderEdit($id)
    {
          $data['result'] = $this->Edit_model->get_Vender($id);
        
        if(isset($data['result']['id']))
        {
            $this->load->library('form_validation');

    		$this->form_validation->set_rules('vendor_typeid','vendor_typeid','required');
            $this->form_validation->set_rules('company_name','company_name','required');
            $this->form_validation->set_rules('owner_name','owner_name','required');
			$this->form_validation->set_rules('email_id','Email','required|valid_email');
			$this->form_validation->set_rules('contact_no','Contact','required|numeric|exact_length[10]');
			$this->form_validation->set_rules('password','Password','required|alpha_numeric');
            $this->form_validation->set_rules('city','City','required');
			$this->form_validation->set_rules('status','status','required'); 
		
			if($this->form_validation->run())     
            {   
                $params = array(
     				'vendor_typeid' => $this->input->post('vendor_typeid'),
                    'company_name' => $this->input->post('name'),
                    'owner_name' => $this->input->post('company_name'),
					'email_id' => $this->input->post('email_id'),
					'contact_no' => $this->input->post('contact_no'),
					'password' => $this->input->post('password'),
					'city' => $this->input->post('city'),
                    'status' => $this->input->post('status'),
                );
                $data['all_vendor_type'] = $this->SAdmin_model->get_all_vendor_type();
                $this->Edit_model->update_Vender($id,$params);            
                redirect('AdminDash/Vender');
            }
            else
            {
                $data['_view'] = 'Admin/VenderList/VenderEdit.php';
                $this->load->view('Admin/VenderList/VenderEdit.php',$data);
            }
        }
        else
          {      
            show_error('The admin you are trying to edit does not exist.');
          } 
    }
    /*
     * Deleting vENDER
     */
    function VenderRemove($id)
    {
        $result = $this->Remove_model->get_vender($id);

        // check if the admin exists before trying to delete it
        if(isset($result['id']))
        {
            $this->Remove_model->delete_vender($id);
            redirect('AdminDash/Vender');
        }
        else
            show_error('The admin you are trying to delete does not exist.');
    }
    
}?>