
  <!-- Main Sidebar Container -->
  <aside class="main-sidebar sidebar-dark-primary elevation-4" >
    <!-- Brand Logo -->
    <a href="#" class="brand-link elevation-4 mr-1">
      <img src="<?php echo base_url('resource/dist/img/logo3.png');?>"
          
           class="brand-image elevation-21"
           style="opacity: .8 ">
      <span class="brand-text font-weight-light"><strong>Admin</strong></span>
    </a>

    <div class="sidebar ">
      <!-- Sidebar user (optional) -->
      <div class="user-panel d-flex">
      </div>

      <!-- Sidebar Menu --><br>
      <nav class="mt-2">
        <ul class="nav nav-pills nav-sidebar flex-column " data-widget="treeview" role="menu" data-accordion="false" role="menu" data-accordion="false">
                        <!-- Dashboard Menu -->
             <li class="nav-item has-treeview nav-link active user-panel">
               <a class="">
                 <?php echo anchor('Dashboard','<i class="nav-icon fas fa-house-damage"></i><p class="hidden-tablet">Dashboard </p>')?>
               </a>
            </li><br>
             <li class="nav-item has-treeview ">
               <a>
                <?php echo anchor('Dashboard/Booking','<i class="nav-icon fas fa-cart-plus"></i><p class="hidden-tablet">Booking Managment</p>','class = nav-link')?>
               </a>
             </li>
              <li class="nav-item has-treeview ">
               <a>
                <?php echo anchor('Dashboard/Services','<i class="nav-icon fas fa-shipping-fast"></i><p class="hidden-tablet">Add Services</p>','class = nav-link')?>
               </a>
             </li>
             <li class="nav-item has-treeview ">
               <a>
                <?php echo anchor('Dashboard/OrderList','<i class="nav-icon fas fa-box-open"></i><p class="hidden-tablet">Order List</p>','class = nav-link')?>
               </a>
             </li>
            
                                         <!--       End     -->
            <li class="nav-item has-treeview user-panel">
               <a href="#" class="nav-link " style="background:white; color:black;">
                  <i class="  nav-icon fab fa-airbnb"></i>
                  <p>Vender &amp; User<i class="right fas fa-angle-left"></i> </p>
               </a>
                <ul class="nav nav-treeview">
                  <li class="nav-item">
                    <a>
                     <?php echo anchor('Dashboard/SuspendVender','<i class="nav-icon far fa-circle text-danger"></i><p class="hidden-tablet">Suspend Vender</p>','class = nav-link')?>
                    </a>
                  </li>
                 </ul>   
                 <ul class="nav nav-treeview">
                  <li class="nav-item">
                    <a>
                     <?php echo anchor('Dashboard/SuspendUser','<i class="nav-icon far fa-circle text-danger"></i><p class="hidden-tablet">Suspend User</p>','class = nav-link')?>
                    </a>
                  </li>
                 </ul> 
                
             </li>
              
             <li class="nav-item has-treeview ">
               <a>
                <?php echo anchor('Dashboard/Category','<i class="nav-icon fas fa-cart-plus"></i><p class="hidden-tablet">Category</p>','class = nav-link')?>
               </a>
             </li>
            <li class="nav-item has-treeview ">
               <a>
                <?php echo anchor('Dashboard/SubCat','<i class="nav-icon fas fa-cart-plus"></i><p class="hidden-tablet">Sub Category</p>','class = nav-link')?>
               </a>
             </li>
            <li class="nav-item has-treeview user-panel">
               <a href="#" class="nav-link " >
                  <i class="nav-icon fas fa-thumbtack"></i>
                  <p>View<i class="right fas fa-angle-left"></i> </p>
               </a>
                <ul class="nav nav-treeview">
                  <li class="nav-item">
                    <a>
                     <?php echo anchor('Dashboard/All_Users','<i class="nav-icon fab fa-pushed"></i><p class="hidden-tablet">All User</p>','class = nav-link')?>
                    </a>
                  </li>
                 </ul>  
                 <ul class="nav nav-treeview">
                  <li class="nav-item">
                    <a>
                     <?php echo anchor('Dashboard/All_Venders','<i class="nav-icon fab fa-pushed"></i><p class="hidden-tablet">All Venders</p>','class = nav-link')?>
                    </a>
                  </li>
                 </ul>   
             </li>
             <li class="nav-item has-treeview ">
               <a>
                <?php echo anchor('Dashboard/Booking','<i class="nav-icon fas fa-cart-plus"></i><p class="hidden-tablet">Inquiry Managent</p>','class = nav-link')?>
               </a>
             </li>
          </ul>
        </nav>
    </div>
  </aside>
   
