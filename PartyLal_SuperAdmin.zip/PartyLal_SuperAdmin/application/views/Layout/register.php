<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?>
<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <title>PartyLal | Register</title>
  <!-- Tell the browser to be responsive to screen width -->
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="shortcut icon" href="resource/dist/img/favicon.ico">
  <!-- Font Awesome -->
  <link rel="stylesheet" href="<?php echo base_url();?>resource/plugins/fontawesome-free/css/all.min.css">
  <!-- Ionicons -->
  <link rel="stylesheet" href="https://code.ionicframework.com/ionicons/2.0.1/css/ionicons.min.css">
  <!-- icheck bootstrap -->
  <link rel="stylesheet" href="<?php echo base_url();?>resource/plugins/icheck-bootstrap/icheck-bootstrap.min.css">
  <!-- Theme style -->
  <link rel="stylesheet" href="<?php echo base_url();?>resource/dist/css/adminlte.min.css">
  <!-- Google Font: Source Sans Pro -->
  <link href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,400i,700" rel="stylesheet">
  <link rel="stylesheet" href="http://fonts.googleapis.com/css?family=Roboto:400,100,300,500">
  <link rel="stylesheet" href="<?php echo base_url();?>assets/bootstrap/css/bootstrap.min.css">
  <link rel="stylesheet" href="<?php echo base_url();?>assets/css/form-elements.css">
  <link rel="stylesheet" href="<?php echo base_url();?>assets/css/style.css">

</head>
<body class="" style="background: #161B21;">

             <div class="login-box col-lg-10 ml-5 mt-5">
                <div class="row">
                    <div class="col-sm-8 col-lg-6 col-lg-offset-4 form-box mt-5">
                      
    <?php echo form_open('Login/Admin_Regis',array("class"=>"f1")); ?>

                        <h3><b>Admin</b> register</h3>
                        <p>Fill the Form and one step ahead to <a href="#">Partilal.com</a></p>
                        

                        <fieldset>
                            <h4>Contact Information</h4>
                          <div class="form-group">
                                
                                <div class="form-group">
                                    <label class="sr-only" for="f1-phone">Phone</label>
                                   <input type="text" placeholder=" Phone" name="contact" value="<?php echo $this->input->post('contact'); ?>" class="form-control" id="contact" />
                                </div>
                                 <div class="form-group">
                                    <label class="sr-only" for="f1-email">Email</label>
                                   <input type="text" placeholder=" Email"  name="email" value="<?php echo $this->input->post('email'); ?>" class="form-control" id="email" />
                                </div>
                               
                                <p>Back to  <?php echo anchor('Login','Login..')?></p>
                                <div class="f1-buttons">
                                    <button type="button" class="btn btn-next">Next</button>
                                </div>
                            </fieldset>
                                <fieldset>
                        <h4>Personal Details:</h4>
                       <div class="form-group">
                            <input type="text" placeholder="Name"  name="name" value="<?php echo $this->input->post('name'); ?>" class="form-control" id="name" />
                         </div>
                        <div class="form-group">
                             <input type="text" placeholder="Address"  name="address" value="<?php echo $this->input->post('address'); ?>" class="form-control" id="address" />
                        </div>
                        <div class="row">
                          <div class="col-md-6 form-group">
                             <input type="text" placeholder="City"  name="city" value="<?php echo $this->input->post('city'); ?>" class="form-control" id="city" />
                          </div>
                            <div class="col-md-6 form-group">
                               <input type="text" placeholder="6-Digit Pin Code"  name="pin" value="<?php echo $this->input->post('pin'); ?>" class="form-control" id="pin" />
                          </div>
                        </div>
                        <div class="f1-buttons">
                            <button type="button" class="btn btn-previous">Previous</button>
                            <button type="button" class="btn btn-next">Next</button>
                        </div>
                    </fieldset>
                            <fieldset>
                                <h4>Security:</h4>
                                <div class="form-group">
                                    <label class="sr-only" for="f1-password">Password</label>
                                   <input type="password" placeholder="Password" name="password" value="<?php echo $this->input->post('password'); ?>" class="form-control" id="password" />
                                </div>
                                <div class="form-group">
                                    <label class="sr-only" for="f1-repeat-password">Repeat password</label>
                                  <input type="password" placeholder="Confirm Password"  name="cpassword" value="<?php echo $this->input->post('cpassword'); ?>" class="form-control" id="cpassword" />
                                </div>
                                <div class="icheck-primary form-group">
                                    <input type="checkbox" id="agreeTerms" name="terms" value="agree">
                                    <input type="hidden"  id="role" name="role" value="2">
                                    <label for="agreeTerms"> I agree to the <a href="#">terms & condition</a>
                                     </label>
                               </div>
                                <div class="f1-buttons">
                                    <button type="button" class="btn btn-previous" >Previous</button>

                                    <button type="submit" class="btn btn-success">Save</button>
                                </div>
                                 
                            </fieldset>
                         <?php echo form_close();?>
                      
                    </div>
                </div>

            </div>
        </div>
</div>
</body>
<script src="<?php echo base_url();?>resource/plugins/jquery/jquery.min.js"></script>
<!-- Bootstrap 4 -->
<script src="<?php echo base_url();?>resource/plugins/bootstrap/js/bootstrap.bundle.min.js"></script>
<!-- AdminLTE App -->
<script src="<?php echo base_url();?>resource/dist/js/adminlte.min.js"></script>
 <script src="<?php echo base_url();?>assets/js/jquery-1.11.1.min.js"></script>
        <script src="<?php echo base_url();?>assets/bootstrap/js/bootstrap.min.js"></script>
        <script src="<?php echo base_url();?>assets/js/jquery.backstretch.min.js"></script>
        <script src="<?php echo base_url();?>assets/js/retina-1.1.0.min.js"></script>
        <script src="<?php echo base_url();?>assets/js/scripts.js"></script>

</body>
</html>
