<?php defined('BASEPATH') OR exit('No direct script access allowed');?> 
 <div class="content-wrapper">

     <div class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1 class="m-0 text-dark">SetUp</h1>
          </div><!-- /.col -->
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="#">Home</a></li>
              <li class="breadcrumb-item active">Setup type</li>
            </ol>
          </div><!-- /.col -->
        </div><!-- /.row -->
      </div><!-- /.container-fluid -->
    </div>
    <!-- /.content-header -->

    <!-- Main content -->
    <section class="col-lg-12 connectedSortable">
        <div class="Container col-md-12">
         <?php echo form_open("AdminDash/Add_Setup" ,['class'=>'navbar-form navbar-right ','role'=>'search']);?>
         <div class="form-group col-md-4 ">
            <?php echo form_input(['name' => 'query','class'=>'form-control', 'placeholder'=>'Enter Email','value'=>set_value('username')]);?>
         </div>
         <div class="form-group col-md-4">
            <?php echo form_submit(['value' => 'search','class'=>'btn btn-primary']);?>
             <?php echo form_submit(['value' => 'Add New','class'=>'btn btn-primary float-sm-right']);?>
        </div>
           
       
     </div>
     
     
    
   
     <table class="table table-hover table-active" >
  <thead style="background-color:#007bff; color: white; ">
    <tr>
      <th scope="col">ID</th>
      <th scope="col">Food Typeid</th>
      <th scope="col">Setup Name</th>
      <th scope="col">Edit</th>
      <th scope="col">Delete</th>
    </tr>
  </thead>
  <tbody>
  <?php foreach($setup as $s){ ?>
    <tr>
    <td><?php echo $s['id']; ?></td>
    <td><?php echo $s['vendor_typeid']; ?></td>
    <td><?php echo $s['setup_name']; ?></td>
    
            <td>
             <button class="btn btn-block btn-outline-info">
               <a href="<?php echo site_url('AdminDash/SetupEdit/'.$s['id']); ?>">Edit</a> 
               </button>
            </td>
            <td>
             <button class="btn btn-block btn-outline-danger">
              <a href="<?php echo site_url('AdminDash/Setup_remove/'.$s['id']); ?>">Delete</a> 
               </button>
            </td>
        
    </tr>
  <?php } ?>
  </tbody>
</table>
<!-- <div class="pull-right">
    <?php// echo $this->pagination->create_links(); ?>    
</div>
 -->
  </section>
 </div>    
