<?php defined('BASEPATH') OR exit('No direct script access allowed');?> 
<body class="">


 
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <div class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1 class="m-0 text-dark"><strong>Complete</strong> Order</h1>
          </div><!-- /.col -->
          <div class="col-sm-12 mt-3" style="background:#EAE7E7; height: 6vh;">
            <ol class="breadcrumb">
              <li class="breadcrumb-item"><a href="<?php echo base_url('AdminDash');?>">Home</a><i
              class="fas fa-angle-double-right mx-2 white-text" aria-hidden="true"></i></li>
              <li class="active"><strong>Order</strong><i
              class="fas fa-angle-double-right mx-2 white-text" aria-hidden="true"></i></li>
              <li class="active"><strong>View All-Complete order</strong></li>
            </ol>
          </div><!-- /.col -->
        </div><!-- /.row -->
      </div><!-- /.container-fluid -->
    </div>
    <!-- /.content-header -->
        


    <!-- Main content -->
    <section class="col-lg-12 connectedSortable">
      <div class="Container col-md-12">
         <?php echo form_open("Order/AddAdmin");?>
         
           <div class="form-group col-md-8 row no-gutters">
              <div class="col">
                <?php echo form_input(['name' => 'query','class'=>'form-control', 'placeholder'=>'Search','value'=>set_value('')]);?>
             </div> 
            <div class="input-group-append mr-2">
                <div class="input-group-text">
                  <span class="fas fa-search"></span>
                </div>
            </div>
             <div class="col-auto ml-5">
                 <?php echo form_submit(['value' => 'search','class'=>'btn btn-success']);?>
                  
             </div>           
                        
                           
       </div>
        
      <ul class="nav nav-tabs">
         <li class="nav-item">
           <a class="nav-link active" data-toggle="tab" href="#today">Today</a>
         </li>
          <li class="nav-item">
           <a class="nav-link" data-toggle="tab" href="#yesterday">Yesterday</a>
         </li>
          <li class="nav-item">
           <a class="nav-link" data-toggle="tab" href="#thswk">This Weak</a>
         </li>
          <li class="nav-item">
            <a class="nav-link " data-toggle="tab" href="#thsmnth">This Month</a>
           </li>  
      </ul>
      <br>
      <div class="Container col-md-12">
        <table class="table table-hover table-active" >
              <thead >
                    <tr>
                      <th scope="col">Serial No.</th>
                      <th scope="col">Name</th>
                      <th scope="col">Package Id</th>
                      <th scope="col">Package Name</th>
                      <th scope="col">Date</th>
                      <th scope="col">Status</th>                     
                    </tr>
             </thead>
        </table>
      <div id="myTabContent" class="tab-content">
          <div class="tab-pane fade active show" id="today">
             <p>Today Data</p>
          </div>
          <div class="tab-pane fade " id="yesterday">
             <p>Yesterday Data</p>
          </div>
          <div class="tab-pane fade" id="thswk">
             <p>This Weak Data</p>
          </div>
          <div class="tab-pane fade" id="thsmnth">
             <p>This Month Data</p>
          </div>
  
  </div>
</div>    
     
    </div></center>
      
         
                                    <!--      Close  -->
        
        </div>
    </section>
            
</div>