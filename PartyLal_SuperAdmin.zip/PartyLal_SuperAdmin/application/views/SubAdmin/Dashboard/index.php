<?php 

    $this->load->view('SubAdmin/include/header');
    $this->load->view('SubAdmin/include/sidebar');
    $this->load->view('SubAdmin/Dashboard/index_work.php');
    $this->load->view('SubAdmin/include/footer');


?>