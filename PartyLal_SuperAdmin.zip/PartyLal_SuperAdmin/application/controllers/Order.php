<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Order extends CI_Controller {

	/**
	 *  Index Page for this controller.
	 */
    
    function __construct()
    {
        parent::__construct();
        $this->load->model('Order_model');
                
    }
   /*
    *  Placed Order Index
    */
    function PlacedOrder()
    {
      
        $data['_view'] =  'Admin/Order/placeorder.php';
       $this->load->view('Admin/Order/placeorder.php',$data);
             
    }
     /*
    *  Placed Order Index
    */
    function UpcomingOrder()
    {
      
        $data['_view'] =  'Admin/Order/UpcomingOrder.php';
       $this->load->view('Admin/Order/UpcomingOrder.php',$data);
             
    }
     /*
    *  Placed Order Index
    */
    function CompleteOrder()
    {
      
        $data['_view'] =  'Admin/Order/CompleteOrder.php';
       $this->load->view('Admin/Order/CompleteOrder.php',$data);
             
    }
}