<?php

class SAdmin_model extends CI_Model
{
    function __construct()
    {
        parent::__construct();
    }
    
    /*
     * Get admin by id
     */
       
     function get_all_admin(){ // view all admin in Super admin

         $this->db->select(['admin.id','admin.name','admin.email','user_role.role_name','admin.contact','admin.city','admin.status']);
           $this->db->from('admin');
           $this->db->join('user_role','user_role.id = admin.role');
           $this->db->where(['admin.role' => '2']);
           $query = $this->db->get();
          return $query->result();
      }
    /*
     * Get admin by id
     */
       
     function get_all_vender(){ // view all admin in Super admin

         $this->db->select(['vendors.id','vendor_type.vendor_type','vendors.owner_name','vendors.company_name','vendors.email_id','vendors.contact_no','vendors.city','vendors.address','vendors.status']);
           $this->db->from('vendors');
            $this->db->join('vendor_type','vendor_type.id = vendors.vendor_typeid');
           $query = $this->db->get();
          return $query->result();
      }
    function get_all_vendertype()
    {
        $this->db->order_by('id', 'desc');
        return $this->db->get('types')->result_array();
    }
    function add_Vendertype($params)
    {
        $this->db->insert('types',$params);
        return $this->db->insert_id();
    }
     function get_all_vendor_type($params = array())
    {
        $this->db->order_by('id', 'desc');
        if(isset($params) && !empty($params))
        {
            $this->db->limit($params['limit'], $params['offset']);
        }
        return $this->db->get('vendor_type')->result_array();
    }


  /*
     * Get all food count
     */
    function get_all_food_count()
    {
        $this->db->from('food');
        return $this->db->count_all_results();
    }


    /*
     * Get all food
     */
    function get_all_food($params = array())
    {
        $this->db->order_by('id', 'desc');
        // if(isset($params) && !empty($params))
        // {
        //     $this->db->limit($params['limit'], $params['offset']);
        // }
        return $this->db->get('food')->result_array();
    }
    /*
     * Add food
     */
    function add_food($params)
    {
        $this->db->insert('food',$params);
        return $this->db->insert_id();
    }
/*
     * Get all vendor_type count
     */
    function get_all_vendor_count()
    {
        $this->db->from('vendor_type');
        return $this->db->count_all_results();
    }

   /** Get all vendor_type
     */
    function get_all_vendor($params = array())
    {
        $this->db->order_by('id', 'desc');
        // if(isset($params) && !empty($params))
        // {
        //     $this->db->limit($params['limit'], $params['offset']);
        // }
        return $this->db->get('vendor_type')->result_array();
    }      
    /*
     * function to add new vendor_type
     */
    function add_vendor_type($params)
    {
        $this->db->insert('vendor_type',$params);
        return $this->db->insert_id();
    }

    /*
     * Get all facilities count
     */
    function get_all_facilities_count()
    {
        $this->db->from('facilities');
        return $this->db->count_all_results();
    }
    /*
     * Get all facilities
     */
    function get_all_facilities($params = array())
    {
        $this->db->order_by('id', 'desc');
        // if(isset($params) && !empty($params))
        // {
        //     $this->db->limit($params['limit'], $params['offset']);
        // }
        return $this->db->get('facilities')->result_array();
    }
     /*
     * function to add new facility
     */
    function add_facility($params)
    {
        $this->db->insert('facilities',$params);
        return $this->db->insert_id();
    }

    /*
     * Get all setup count
     */
    function get_all_setup_count()
    {
        $this->db->from('setup');
        return $this->db->count_all_results();
    }
        
    /*
     * Get all setup
     */
    function get_all_setup($params = array())
    {
        $this->db->order_by('id', 'desc');
        // if(isset($params) && !empty($params))
        // {
        //     $this->db->limit($params['limit'], $params['offset']);
        // }
        return $this->db->get('setup')->result_array();
    }
        
    /*
     * function to add new setup
     */
    function add_setup($params)
    {
        $this->db->insert('setup',$params);
        return $this->db->insert_id();
    }

     /*
     * Get all decoration_type count
     */
    function get_all_decoration_type_count()
    {
        $this->db->from('decoration_type');
        return $this->db->count_all_results();
    }
        
    /*
     * Get all decoration_type
     */
    function get_all_decoration_type($params = array())
    {
        $this->db->order_by('id', 'desc');
        // if(isset($params) && !empty($params))
        // {
        //     $this->db->limit($params['limit'], $params['offset']);
        // }
        return $this->db->get('decoration_type')->result_array();
    }
        
    /*
     * function to add new decoration_type
     */
    function add_decoration_type($params)
    {
        $this->db->insert('decoration_type',$params);
        return $this->db->insert_id();
    }

     /*
     * Get all special count
     */
    function get_all_special_count()
    {
        $this->db->from('special');
        return $this->db->count_all_results();
    }
        
    /*
     * Get all special
     */
    function get_all_special($params = array())
    {
        $this->db->order_by('id', 'desc');
        // if(isset($params) && !empty($params))
        // {
        //     $this->db->limit($params['limit'], $params['offset']);
        // }
        return $this->db->get('special')->result_array();
    }
        
    /*
     * function to add new special
     */
    function add_special($params)
    {
        $this->db->insert('special',$params);
        return $this->db->insert_id();
    }
    
    /*
     * function to add new City
     */
    function cityaddModel($x)
    {
        $state = $this->input->post('state');
        $city_name = $this->input->post('city_name');
        $w=array(
            'state' => $state,       
            'city_name' => $city_name,
            'image' => $x, 
            
                );
        $this->db->insert('city',$w);
    }
    function Show()
    {
       $q = $this->db->get('city');
        $rs = $q->result();
        return $rs;
    }

    /*
     * Get type by id
     */
    function get_type($id)
    {
        return $this->db->get_where('types',array('id'=>$id))->row_array();
    }
    /*
     * function to update type
     */
    function update_type($id,$params)
    {
        $this->db->where('id',$id);
        return $this->db->update('types',$params);
    }
 }
?>