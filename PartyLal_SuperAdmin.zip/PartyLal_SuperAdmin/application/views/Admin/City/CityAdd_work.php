
<body class="">
  <div class="content-wrapper">
     <div class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1 class="m-0 text-dark">City Add</h1>
          </div><!-- /.col -->
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="#">Home</a></li>
              <li class="breadcrumb-item">Add</li>
             
            </ol>
          </div><!-- /.col -->
        </div><!-- /.row -->
      </div><!-- /.container-fluid -->
    </div>
    <section class="col-lg-12 connectedSortable ml-5">
      <div class="login-box">
    <?php echo form_open("AdminDash/AddCity"); ?>
  
  <?php if($error = $this->session->flashdata('login_response')):?>
      <div class="row">
        <div class="col-lg-12">
            <div class="alert alert-dismissible alert-danger">
               <?php echo $error; ?>
            </div>
       </div>
      </div>
    <?php endif; ?>  
  <!-- /.login-logo -->
  <div class="card">
    <div class="card-body login-card-body">
      <p class="login-box-msg">Sign in to start your session</p>
        <div class="input-group mb-3">
          <?php echo form_input(['name' => 'state','class'=>'form-control', 'placeholder'=>'state','value'=>set_value('state')])?>
          <div class="input-group-append">
            <div class="input-group-text">
              <span class="fas fa-address-book"></span>
            </div>
          </div>
        </div>
         <div class="input-group mb-3">
          <?php echo form_input(['name' => 'city_name','class'=>'form-control', 'placeholder'=>'city_name','value'=>set_value('city_name')])?>
          <div class="input-group-append">
            <div class="input-group-text">
              <span class="fas fa-address-book"></span>
            </div>
          </div>
        </div>
         <div class="input-group mb-3">
          <?php echo form_upload(['name' => 'image','class'=>'form-control','value'=>set_value('image')])?>
        </div>
       
     
       
        <div class="col-lg-12">
          <div class="col-4">
            <?php echo form_submit(['value' =>'Submit','class'=>'btn btn-primary btn-block'])?>
          </div>
          <!-- /.col -->
        </div>
    </div>
    <!-- /.login-card-body -->
  </div>
  <?php echo form_close();?>
</div>
    </section>      
  </div>
</body> 